module.exports = {
    name: "QQ614096466",
    uniacid: "5",
    acid: "5",
    multiid: "0",
    version: "1.0.0",
    siteroot: "https://ligentshop.com/app/index.php",
    design_method: "3"
};
// 存储店铺id:acid
var uniacidObj={}
uniacidObj.uniacid = module.exports.uniacid
wx.setStorageSync('uniacidObj', uniacidObj)
var uniacid = wx.getStorageSync('uniacidObj')
console.log("+++++++++++++++uniacid:",uniacid.uniacid)

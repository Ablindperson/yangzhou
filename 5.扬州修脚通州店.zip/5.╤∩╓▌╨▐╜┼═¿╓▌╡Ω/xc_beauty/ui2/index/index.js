var app = getApp(), common = require("../common/common.js");

// require("../common/test.js")
function time_up(n) {
    var e = setInterval(function() {
        var a = n.data.flash;
        if ("" != a && null != a && 0 < a.length) {
            for (var t = 0; t < a.length; t++) 0 < a[t].second ? a[t].second = a[t].second - 1 : 0 < a[t].min ? (a[t].min = a[t].min - 1, 
            a[t].second = 59) : 0 < a[t].hour ? (a[t].hour = a[t].hour - 1, a[t].min = 59, a[t].second = 59) : 0 < a[t].day ? (a[t].day = a[t].day - 1, 
            a[t].hour = 23, a[t].min = 59, a[t].second = 59) : a.splice(t, 1);
            n.setData({
                flash: a
            });
        } else clearInterval(e);
    }, 1e3);
}


Page({
    data: {
        pagePath: "../index/index",
        indicatorDots: !0,
        autoplay: !0,
        interval: 5e3,
        duration: 1e3,
        imgheights: [],
        current: 0,
        isPageBottom:0,
    },
    ////////////////////////
  //执行提交form表单操作
    formGoTo: function(e) {
      var that = this
      var formid = e.detail.formId;//在参数中获取formid
      var content = e.detail.target.dataset.name//记录用户的操作
      console.log('form发生了submit事件，推送码为：', formid)
      console.log('button点击事件来自：', content)
      //执行formid提交方法
      that.submintFromId(formid)
      console.log(formid)
     ////// //////////
      var obj = wx.getStorageSync('obj')
      console.log("&&&&&&&&&&:", obj.openid)
//////////////
    },
  //向后台发送formid
  submintFromId: function (formid) {
    var that = this
    wx.request({
      url: 'https://wpdev.ligentshop.com/api/xcx/send_formid',
      method: "post",
      data: {
        fm: formid,
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      //因为自己开始跳转页面和提交formid操作是分开的，调试时没问题，正式版本就有问题了，当时没有注意到，后来意识到是跳转事件给打断了，各位用的时候请注意
      // complete: function () {
      //   wx.navigateTo({
      //     url: "../order/order"
      //   });
      // }
    })
  },
    ////////////////////////
    imageLoad: function(a) {
        //var t = a.detail.width, n = t / (e = a.detail.height);
        var t = 480, n = t / (e = 320);
        //console.log(t, e);
        var e = 750 / n, o = this.data.imgheights;
        o.push(e), this.setData({
            imgheights: o
        });
    },
    bindchange: function(a) {
        //console.log(a.detail.current),
            this.setData({
            current: a.detail.current
        });
    },
    call: function() {
        var a = this.data.map;
        wx.makePhoneCall({
            phoneNumber: a.content.mobile
        });
    },
    // map: function() {
    //     var a = this.data.map;
    //     wx.openLocation({
    //         latitude: parseFloat(a.content.latitude),
    //         longitude: parseFloat(a.content.longitude),
    //         name: a.content.address,
    //         address: a.content.address,
    //         scale: 28
    //     });
    // },
    
    link: function(a) {
        var t = a.currentTarget.dataset.link, n = a.currentTarget.dataset.appid;
        "" != n && null != n ? wx.navigateToMiniProgram({
            appId: n,
            path: "",
            success: function(a) {
                // console.log("22222222",a);
            },
            fail: function() {
              // console.log("3333333");
                wx.showModal({
                    title: "错误",
                    content: "跳转失败"
                });
            }
        }) : "" != t && null != t && (t = escape(t), wx.navigateTo({
            url: "../../pages/link/link?&url=" + t
        }));
    },
    getcoupon: function(a) {
        var t = a.currentTarget.dataset.index;
        wx.navigateTo({
            url: "../../pages/coupon/index?&id=" + this.data.coupon[t].id
        });
    },

    onLoad: function(a) {
      console.log(a);
     
        var r = this;
        //if (undefined == t.data.scrollHeight ) {
            wx.getSystemInfo({
                success: function(res) {
                    r.setData(
                        {scrollHeight:res.windowHeight}
                    )
                }
            })
        //}

        common.config(r), common.theme(r), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "index"
            },
            showLoading: !1,
            success: function(a) {
                var t = a.data;
                console.log(t)
                if ("" != t.data) {
                    if ("" != t.data.banner && null != t.data.banner && r.setData({
                        banner: t.data.banner
                    }), "" != t.data.map && null != t.data.map && r.setData({
                        map: t.data.map
                    }), "" != t.data.nav && null != t.data.nav && r.setData({
                        nav: t.data.nav
                    }), "" != t.data.coupon && null != t.data.coupon && r.setData({
                        coupon: t.data.coupon
                    }), "" != t.data.group && null != t.data.group && r.setData({
                        group: t.data.group
                    }), "" != t.data.flash && null != t.data.flash) {
                        for (var n = t.data.flash, e = 0; e < n.length; e++) {
                            var o, s, i, l;
                            o = parseInt(parseInt(n[e].fail) / 86400), s = parseInt((n[e].fail - 86400 * o) / 3600), 
                            i = parseInt((n[e].fail - 86400 * o - 3600 * s) / 60), l = parseInt(n[e].fail % 60), 
                            n[e].day = o, n[e].hour = s, n[e].min = i, n[e].second = l;
                        }
                        r.setData({
                            flash: n
                        }), time_up(r);
                    }
                    if ("" != t.data.pclass && null != t.data.pclass && r.setData({
                        pclass: t.data.pclass
                    }), "" != t.data.sort && null != t.data.sort) r.setData({
                        sort: t.data.sort
                    }); else {
                        r.setData({
                            sort: [ {
                                name: "banner",
                                status: 1
                            }, {
                                name: "map",
                                status: 1
                            }, {
                                name: "coupon",
                                status: 1
                            }, {
                                name: "group",
                                status: 1
                            } ]
                        });
                    }
                    r.data.isPageBottom = 3 ;
                    //r.setData({
                    //    isPageBottom:3
                    //})
                }
            }
        });
    },
    rolldown: function (){
    wx.pageScrollTo({
        scrollTop: 500,
        duration: 500
    })},

    onUserCaptureScreen:(function(){}),
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() { },
    onReachBottom: function() {
        var t = this;
        t.setData(
            {isPageBottom : 1}
        )
        //console.log('onReachBottom:',t.data.isPageBottom)
    },
    onPageScroll:function(e) {
        //if ( 0 != this.data.isPageBottom) {
        //    this.setData({
        //        isPageBottom : 0
        //    })
        //    console.log('向上：'+this.data.isPageBottom);
        //}

        var t = this;

        if (e.scrollTop <= 0) {
            // 滚动到最顶部
            e.scrollTop = 0;
            //console.log('到底:',e.scrollTop);
        } else if (e.scrollTop >= t.data.scrollHeight) {
            // 滚动到最底部？无法判断
            //t.data.isPageBottom = 1;
             e.scrollTop = t.data.scrollHeight;
        }
        //console.log(e.scrollTop);

        if (e.scrollTop < this.data.scrollTop && e.scrollTop < t.data.scrollHeight) {
            if (t.data.isPageBottom != 0) {
                t.setData({
                    isPageBottom: 0
                })
            }
            //console.log('向下划屏 '+ t.data.isPageBottom +" :", t.data.scrollHeight)
        }
            //}else{
        //    //console.log('向上划屏 '+ t.data.isPageBottom + " :", t.data.scrollHeight)    }

        this.setData({
            scrollTop: e.scrollTop
        })

    },




    onShareAppMessage: function() {
        var a = this, t = "/xc_beauty/ui2/index/index";
        t = escape(t);
        var n = a.data.config.title + "-首页";
        "" != a.data.config.share_index_title && null != a.data.config.share_index_title && (n = a.data.config.share_index_title);
        var e = "";
        "" != a.data.config.share_index_img && null != a.data.config.share_index_img && (e = a.data.config.share_index_img);
        var o = "/xc_beauty/pages/base/base?&share=" + t, s = 1;
      console.log("------", app.userinfo.openid)
      return "" != app.share && null != app.share && "" != app.share.content && null != app.share.content && (s = app.share.content.status),       
        1 == s && (o = o + "&scene=" + app.userinfo.openid),
            //console.log(o),
        {
            title: n,
            path: o,
            imageUrl: e,
            success: function(a) {
                // console.log(a);
            },
            fail: function(a) {
                // console.log(a);
            }
        };
    }
});
var app = getApp(), common = require("../common/common.js");
var calendarSignData;
var date;
var calendarSignDay;
var uniacid1 = wx.getStorageSync('uniacidObj')
var uniacid = uniacid1.uniacid
var openid = wx.getStorageSync('openid')
var ss = {
  openid: openid,
  uniacid: uniacid
};
Page({
  data: {
    num:0,//点击签到按钮次数
    mes:"",
    jf:"",
    is_show:false,
  	arr: [],
    arr1: [],
    sysW: null,
    lastDay: null,
    firstDay: null,
    weekArr: ['日', '一', '二', '三', '四', '五', '六'],
    year: null
  },
  //获取日历相关参数
  dataTime: function () {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth();
    var months = date.getMonth() + 1;
    //获取现今年份
    this.data.year = year;
    //获取现今月份
    this.data.month = months;
    //获取今日日期
    this.data.getDate = date.getDate();
    //最后一天是几号
    var d = new Date(year, months, 0);
    this.data.lastDay = d.getDate();
    //第一天星期几
    let firstDay = new Date(year, month, 1);
    this.data.firstDay = firstDay.getDay();
  },
 qiandao:function(){
   var n=this.data.num
   if(n==0){
         n++
   wx.setStorageSync('nn', n)
   var nn = wx.getStorageSync('nn')
   console.log("______",nn)
   this.data.num=nn
//  拿出店铺id uniacid
   var uniacid1 = wx.getStorageSync('uniacidObj')
   var uniacid = uniacid1.uniacid
  //拿出openid
  var openid = wx.getStorageSync('openid')
  var that = this
   app.util.newrequest({
     url: 'score/signscore',
     method: 'POST',  
     data: ss,
     success: function (res) {
       console.log("点击签到res--:", res) 
       app.util.newrequest({
         url: 'score/checktotal',
         method: 'post',
         data: ss,
         success: function (res) {
           console.log("积分计算:", res)
           if (res.data.code == 1) {
             that.setData({
               mes:"已签到",
               num: 1,
               jf: res.data.result,
               is_show:true
             })
           }
         }
       });
     //点击签到后刷新日历 
   var aa = [];
   app.util.newrequest({
     url:'score/signrecord',
     method:'post',
     data:ss,
     success:function(res){
       console.log("当月签到时间：",res)
       res.data.result.forEach(function (item, index) {
           console.log(item.day); //这里的item就是从数组里拿出来的每一个每一组
           aa[item.day-0] = item.day-0;
          })
         console.log("aa:",aa)
         that.setData({
           arr1:aa
         });
   
     }
   });





       wx.showToast({
         title: '签到成功',
         icon: 'success',
         duration: 2000//持续的时间
       })
      
     }
   });
   }else{
     wx.showToast({
     title: '小主您今天已签到，明天记得再来哦~！',
     icon: 'none',
     duration: 2000//持续的时间
    })
   }

 },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:
   function (options) {   
	// 获取储存oppenid   
    var that = this
    var s = { op: "store_order" };
    app.util.request({
      url: "entry/wxapp/service",
      data: s,
      success: function (t) {
        var e = t.data;
        console.log(e)
        wx.setStorageSync('openid', e.data.userinfo.openid)
      }
    });
   //用封装的函数调用接口   
   //当天是否签到
    app.util.newrequest({
     url:'score/todayIsSign',
     method:'post',
     data:ss,
     success:function(res){
       console.log("是否签到:", res)
       if (res.data.code == 1) {
                app.util.newrequest({
                  url: 'score/checktotal',
                  method: 'post',
                  data: ss,
                  success: function (res) {
                    console.log("积分计算:", res)
                    if (res.data.code == 1) {
                      that.setData({
                        mes:"已签到",
                        num: 1,
                        jf: res.data.result,
                        is_show:true
                      })
                    } 
                  }
                });
       }else{
         that.setData({
           num: 0,
           mes: "签到"
         })
       }
     }
   });
   	  that.dataTime();
    //根据得到今月的最后一天日期遍历 得到所有日期
    for (var i = 1; i < that.data.lastDay + 1; i++) {
      that.data.arr.push(i);
    }
    var res = wx.getSystemInfoSync();
    // 获取签到时间
    var aa = [];
	that.setData({
      sysW: res.windowHeight / 16,//更具屏幕宽度变化自动设置宽度
      marLet: that.data.firstDay,
      arr: that.data.arr,
      year: that.data.year,
      getDate: that.data.getDate,
      month: that.data.month,
      //arr1:aa
    });

   app.util.newrequest({
     url:'score/signrecord',
     method:'post',
     data:ss,
     success:function(res){
       console.log("当月签到时间：",res)
       res.data.result.forEach(function (item, index) {
           console.log(item.day); //这里的item就是从数组里拿出来的每一个每一组
           aa[item.day-0] = item.day-0;
           console.log("AA:",aa)
 
          })
	       console.log("aa:",aa)
	       that.setData({
           arr1:aa
         });
	 
     }
   });
  },
  
 
})
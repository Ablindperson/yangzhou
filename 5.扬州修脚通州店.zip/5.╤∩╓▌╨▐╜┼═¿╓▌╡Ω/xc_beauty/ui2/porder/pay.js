var app = getApp(), common = require("../common/common.js");

function wxpay(a, t) {
    a.appId;
    var o = a.timeStamp.toString(), e = a.package, n = a.nonceStr, d = a.paySign.toUpperCase();
    var redir1 = "../order/order";
    if (t.data.list.out_trade_no != undefined) {
        //console.log(t.data.list.out_trade_no)
        redir1 = "../order/detail?&out_trade_no=" + t.data.list.out_trade_no
    }
    if (3==t.data.list.order_type) {
        redir1 = "../group/detail?&id=" + t.data.list.group;
    }

    //console.log("wxpay::"+redir1);
    wx.requestPayment({
        timeStamp: o,
        nonceStr: n,
        package: e,
        signType: "MD5",
        paySign: d,
        success: function(a) {
            wx.showToast({
                title: "支付成功",
                icon: "success",
                duration: 2e3
            }), setTimeout(function() {
                3 == t.data.list.order_type ? wx.redirectTo({
                    url: "../group/detail?&id=" + t.data.list.group
                }) : wx.redirectTo({
                    url: redir1
                });
            }, 2e3);
        },
        fail: function(a) {
            console.log(a);
        }
    });
}

Page({
    data: {
        pay_type: 5,
        coupon_curr: -1,
        coupon_uid:-1
    },
    menu_on: function() {
        this.setData({
            menu: !0,
            shadow: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1,
            pay: !1
        });
    },
    pay_choose: function(a) {
        var t = a.currentTarget.dataset.index;
        t != this.data.pay_type && this.setData({
            pay_type: t
        });
    },
    input: function(a) {
        switch (a.currentTarget.dataset.name) {
          case "content":
            this.setData({
                content: a.detail.value
            });
            break;

          case "password":
            this.setData({
                password: a.detail.value
            });
        }
    },
    coupon_choose: function(a) {
        var t = this, o = a.currentTarget.dataset.index;
        if (o != t.data.coupon_curr) {
            var e = t.data.coupon[o].coupon.name, n = t.data.list.amount;
            "" != (d = t.data.card) && null != d && 1 == t.data.userinfo.card && 1 == d.content.discount_status && (n = (parseFloat(n) * parseFloat(d.content.discount) / 10).toFixed(2)), 
            n = (parseFloat(n) - parseFloat(e)).toFixed(2), t.setData({
                coupon_curr: o,
                coupon_uid: t.data.coupon[o]['id'],
                coupon_price: e,
                o_amount: n
            });
        } else {
            var d;
            n = t.data.list.amount;
            "" != (d = t.data.card) && null != d && 1 == t.data.userinfo.card && 1 == d.content.discount_status && (n = (parseFloat(n) * parseFloat(d.content.discount) / 10).toFixed(2)), 
            t.setData({
                coupon_curr: -1,
                coupon_uid:-1,
                coupon_price: null,
                o_amount: n
            });
        }
    },
    submit: function(a) {
        var o = this;
        if ( 2 == o.data.pay_type && o.data.userinfo.money - o.data.o_amount < 0) {
            wx.showModal({
                title: '提示',showCancel:0,
                content: '您的余额不足，请选择其他支付方式或联系商家充值！',
                success: function (res) {
                }
            });
            return
        }
        if (1 == o.data.pay_type) { //1微信支付
            var t = {
                out_trade_no: o.data.list.out_trade_no,
                coupon_uid: o.data.coupon_uid,
                pay_type: o.data.pay_type,
                form_id: a.detail.formId
            };
            -1 != o.data.coupon_curr && (t.coupon_id = o.data.coupon[o.data.coupon_curr].cid), 
            "" != o.data.content && null != o.data.content && (t.content = o.data.content), 
            app.util.request({
                url: "entry/wxapp/orderpay",
                data: t,
                success: function(a) {
                    var t = a.data;
                    "" != t.data && (1 == t.data.status ? (console.log(t.data), wxpay(t.data, o)) : 2 == t.data.status && wx.redirectTo({
                        url: "../../pages/porder/success"
                    }));
                }
            });
        } else if( 2 == o.data.pay_type) //2余额支付
        {
           o.setData({
            pay: !1,
            coupon_uid: o.data.coupon_uid,
            sign: !0,
            shadow: !0,
            form_id: a.detail.formId
          });
        }else if( 5==o.data.pay_type) // 5到店付
        {
            var t = {
              out_trade_no: o.data.list.out_trade_no,
              coupon_uid: o.data.coupon_uid,
              pay_type: o.data.pay_type,
              form_id: a.detail.formId
            };
            -1 != o.data.coupon_curr && (t.coupon_id = o.data.coupon[o.data.coupon_curr].cid),
              "" != o.data.content && null != o.data.content && (t.content = o.data.content),
              app.util.request({
                url: "entry/wxapp/orderpay",
                data: t,
                success: function (a) {
                    var d=a.data.data
                    //console.log(d)
                    var urlPayed = (null != d.group_id && undefined != d.group_id ) ?
                                  "../../pages/group/detail?&id="+d.group_id
                                 :"../../pages/order/order";
                    wx.showModal({
                      title: '提示',
                      content: '订单提交成功，需到店付款后才能使用!',
                      success: function (res) {
                        wx.redirectTo({url:urlPayed})
                      }
                    });
                }
              });

        }
    },
    sign_close: function() {
        this.setData({
            shadow: !1,
            sign: !1,
            password: ""
        });
    },
    sign_btn: function() {
        //console.log("sign_btn")
        var o = this, a = o.data.password;
        if ("" == a || null == a) o.setData({
            sign_error: !0
        }); else {
            var t = {
                out_trade_no: o.data.list.out_trade_no,
                coupon_uid: o.data.coupon_uid,
                pay_type: o.data.pay_type,
                form_id: o.data.form_id,
                password: a
            };
            -1 != o.data.coupon_curr && (t.coupon_id = o.data.coupon[o.data.coupon_curr].cid), 
            "" != o.data.content && null != o.data.content && (t.content = o.data.content), 
            app.util.request({
                url: "entry/wxapp/orderpay",
                data: t,
                success: function(a) {
                    var t = a.data.data;
                    "" != t && (o.setData({
                        shadow: !1,
                        sign: !1,
                        password: ""
                    }), 1 == t.status ? wxpay(t.data, o) : 2 == t.status && (wx.showToast({
                        title: "支付成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        //console.log('sign_btn:'+o.data.list.order_type)
                        //console.log(t)
                        var redirUrl = null
                        switch ( o.data.list.order_type ) {
                            case "3":
                                //console.log(3);//团购
                                redirUrl =  "../../pages/group/detail?&id=" + t.group_id
                                break;
                            case "4":
                                //console.log(4)
                                redirUrl = "../../pages/order/order"
                                break;
                            default:
                                //console.log("*")
                                redirUrl = "../order/detail?&out_trade_no=" + o.data.list.out_trade_no
                        }
                        wx.redirectTo({url:redirUrl})
                    }, 2e3)));
                }
            });
        }
    },
    onLoad: function(a) {
        var e = this;
        //console.log('porder.pay ---> out_trade_no:'+e.out_trade_no);
        common.config(e), common.theme(e),
        app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "detail",
                out_trade_no: a.out_trade_no
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && (e.setData({
                    list: t.data,
                    o_amount: t.data.amount
                }), app.util.request({
                    url: "entry/wxapp/user",
                    showLoading: !1,
                    data: {
                        op: "userinfo"
                    },
                    success: function(a) {
                        var t = a.data;
                        "" != t.data && (e.setData({
                            userinfo: t.data
                        }),
                            app.util.request({
                            url: "entry/wxapp/index",
                            showLoading: !1,
                            data: {
                                op: "card"
                            },
                            success: function(a) {
                                var t = a.data;
                                if ("" != t.data) {
                                    var o = e.data.o_amount;
                                    1 == t.data.content.level_status && 1 == e.data.userinfo.card && null != e.data.userinfo.card_price && "" != e.data.userinfo.card_price ? (t.data.content.discount = e.data.userinfo.card_price, 
                                    o = (parseFloat(o) * parseFloat(e.data.userinfo.card_price) / 10).toFixed(2)) : 1 == t.data.content.discount_status && 1 == e.data.userinfo.card && (o = (parseFloat(o) * parseFloat(t.data.content.discount) / 10).toFixed(2)), 
                                    e.setData({
                                        card: t.data,
                                        o_amount: o
                                    });
                                }
                            },
                            complete: function() {
                                app.util.request({
                                    url: "entry/wxapp/order",
                                    showLoading: !1,
                                    data: {
                                        op: "coupon",
                                        pay:1,
                                        amount: e.data.o_amount
                                    },
                                    success: function(a) {
                                        var t = a.data.data
                                        var coupon_curr = -1
                                        var coupon_price = 0;
                                        //Object.getOwnPropertyNames(t.data).forEach(function(key){//Reflect.ownKeys(t).forEach(function(i){ if (i<t.length)
                                        for (var i in t){
                                            if ( t[i].coupon.name - coupon_price > 0) {
                                                coupon_curr = i;
                                                coupon_price = t[i].coupon.name;
                                            }
                                        }
                                        "" != t && e.setData({
                                            coupon: t, coupon_curr: coupon_curr, coupon_price: coupon_price,
                                            o_amount:(e.data.o_amount - coupon_price),
                                            coupon_uid:t[coupon_curr]['id']
                                        });
                                    }
                                });
                                wx.setNavigationBarTitle({
                                    title:  e.data.list.order_type!="4"?'订单信息':'预约信息'
                                })
                            }
                        }));
                    }
                }));
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
var app = getApp(), common = require("../common/common.js");
var extend=function(o,n){ for (var p in n){ if(n.hasOwnProperty(p) && (!o.hasOwnProperty(p) ))  o[p]=n[p]; } return o; };
var now = new Date(); //当前日期
var nowDayOfWeek = now.getDay(); //今天本周的第几天
var nowDay = now.getDate(); //当前日
var nowMonth = now.getMonth(); //当前月
var nowYear = now.getYear(); //当前年
nowYear += (nowYear < 2000) ? 1900 : 0; //有2100问题
var currentHours = now.getHours();//当前小时
var currentMinute = now.getMinutes();//当前分钟`

var lastMonthDate = new Date(); //上月日期
lastMonthDate.setDate(1);
lastMonthDate.setMonth(lastMonthDate.getMonth()-1);
var lastYear = lastMonthDate.getYear();
var lastMonth = lastMonthDate.getMonth();
var hs = this

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "H+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

function GetDateStr(a) {
    var t = new Date();
    t.setDate(t.getDate() + a);
    t.getFullYear();
    return t.getMonth() + 1 + "月" + t.getDate() + "日";
}

function getMyDay(a) {
    var t = new Date();
    return t.setDate(t.getDate() + a), 0 == t.getDay() && "周日", 1 == t.getDay() && "周一", 
    2 == t.getDay() && "周二", 3 == t.getDay() && "周三", 4 == t.getDay() && "周四", 5 == t.getDay() && "周五", 
    6 == t.getDay() && "周六", t.getDay();
}

function getMyDay2(a) {
    var t, e = new Date();
    return e.setDate(e.getDate() + a), 0 == e.getDay() && (t = "周日"), 1 == e.getDay() && (t = "周一"), 
    2 == e.getDay() && (t = "周二"), 3 == e.getDay() && (t = "周三"), 4 == e.getDay() && (t = "周四"), 
    5 == e.getDay() && (t = "周五"), 6 == e.getDay() && (t = "周六"), t;
}

function get_time(d) {
    var w = d.data.times, r = [], s = !1, cid, mid, member;
    d.setData({
        time_list: s,
        tip: s
    })
    //1 == d.data.online_time && app.util.request({
    //    url: "entry/wxapp/user",
    //    showLoading: !1,
    //    data: {
    //        op: "plan_date",
    //        plan_date: d.data.date[d.data.date_curr].date,
    //        id: d.data.id
    //    },
    //    success: function(t) {
    //        var e = t.data;
    //        if ("" != e.data) {
    //            if (1 == e.data.status)
    for (var a = 0; a < w.length; a++)
        w[a].week == d.data.date[d.data.date_curr].week ? r = w[a].content : 7 == w[a].week && 0 == d.data.date[d.data.date_curr].week && (r = w[a].content);
    //else s = !0;
    //r = check_today_time(new Date(nowYear+'-'+( d.data.date[d.data.date_curr].date) .replace('月','-').replace('日','')),r)
    cid = (undefined!=d.data.sortCurr && -1 != d.data.sortCurr) ? d.data.class[d.data.sortCurr].id : -1;
    mid =  (0 == d.data.owner && -1 != d.data.tagCurr) ? d.data.member[d.data.tagCurr].id : -1;
    member = ("" != d.data.member_id && null != d.data.member_id ) ? d.data.member_id : -1;
    app.util.request({
        url: "entry/wxapp/user",
        data: {
            op: "times_log2",
            owner: d.data.owner,
            id: d.data.id,
            ot: d.data.order_type,
            multi: d.data.multi_curr,
            cid: cid,
            mid: mid,
            member: d.data.member_id,
            plan_date: d.data.date[d.data.date_curr].date,
            //list: JSON.stringify(r),
            index: d.data.date[d.data.date_curr].index
        },
        success: function (t) {
            var e = t.data;
            //TODO
            r = ("" != e.data) ? check_today_time(new Date(nowYear + '-' + ( d.data.date[d.data.date_curr].date).replace('月', '-').replace('日', '')), e.data, d.data.owner)
                : check_today_time(new Date(nowYear + '-' + ( d.data.date[d.data.date_curr].date).replace('月', '-').replace('日', '')), r, d.data.owner);
            d.setData({
                tip: s,
                time_curr: -1,
                time_list: r
            });
            if (undefined != d.data.multiOrder && undefined != d.data.date_curr && 1 == d.data.multi_curr[d.data.date_curr]
                && -1 != d.data.multiOrder.indexOf(d.data.date_curr)) {
                d.setData({startTime: d.data.multiStartTime[d.data.date_curr].first})
                //d.protect_time_choose1(d)
            }
        }
    })
   //: d.setData({
   //     time_curr: -1,
   //     time_list: r,
   //     tip: s
   // })
    //;
    //} //if
    //} //success
    //}); //request
}

function check_today_time(startDate,l,owner){
    var j,cm,l,ll,b2;
    if (0==owner) {
        for (var i in l){
            ll=l[i].timelist;
            cm = new Date(); b2 = 2048; ll[0].now_mask=0;
            cm.setHours(ll[0].start.split(":")[0],ll[0].start.split(":")[1],0);
            cm=cm.Format("m");
            for (var k=0;k<60 && k<cm ;k=k+5) {
                ll[0].now_mask += b2; b2 = b2>>1;
            }
            //当天最后一条
            j = ll.length - 1;
            if (0 != ll[j].end.split(':')[1]) { //非整点
                var b2 = 2048; ll[j].now_mask=0;
                //console.log(ll[j].start+' -  '+ll[j].end)
                for (var k=0;k<60;k=k+5) {
                    if (k >= ll[j].end.split(':')[1] ){
                        ll[j].now_mask += b2;
                    }
                    b2 = b2>>1;
                }
            }
        }
    }else{
        cm = new Date(); b2 = 2048; l[0].now_mask=0;
        cm.setHours(l[0].start.split(":")[0],l[0].start.split(":")[1],0);
        cm=cm.Format("m");
        for (var k=0;k<60 && k<cm ;k=k+5) {
            l[0].now_mask += b2; b2 = b2>>1;
        }
        //当天最后一条
        j = l.length - 1;
        if (0 != l[j].end.split(':')[1]) { //非整点
            var b2 = 2048; l[j].now_mask=0;
            //console.log(l[j].start+' -  '+l[j].end)
            for (var k=0;k<60;k=k+5) {
                if (k >= l[j].end.split(':')[1] ){
                    l[j].now_mask += b2;
                }
                b2 = b2>>1;
            }
        }
    }
    return l
}

Page({
    data: {
        owner:0,
        footer_curr: 3,
        date_curr: 0,
        time_curr: -1,
        sortCurr:-1,
        tagCurr:-1,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        sort_list:!1,
        sortName: "服务",
        tagName: "技师",
        type:1

    },
    order_call: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.list[this.data.curr].userinfo.mobile
        });
    },
    map: function() {
        var a = this;
        wx.openLocation({
            latitude: parseFloat(a.data.list[a.data.curr].userinfo.map.latitude),
            longitude: parseFloat(a.data.list[a.data.curr].userinfo.map.longitude),
            address: a.data.list[a.data.curr].userinfo.map.address,
            scale: 28
        });
    },
    choose: function(t) {
        var d=this,a = t.currentTarget.dataset.index;
        if (a != d.data.type ) {
            d.setData({
                type: a,
                list: [],
                page: 1,
                shadow:!1,
                isbottom: !1,
                sort_list: !1,
                tag_list: !1,
            });
        }
        d.freshData(d)
    },
    freshData:function(d){
        if (1== d.data.type) {
            d.fetch_order_list(d)
        }
        if (2== d.data.type){
            get_time(d)
        }
    },
    closeAll:function(){
        this.setData({sort_list: !1,tag_list: !1,shadow:!1});
    },
    all: function(t) {
        var d = this;
        if ( -1 == d.data.sortCurr && -1 == d.data.tagCurr) {
            d.setData({ shadow:!1,sort_list: !1, tag_list: !1 })
            return
        }
        if( 0 != d.data.curr ) { d.setData({
            curr: 0,
            sort_list: !1,
            tag_list: !1,
            shadow:!1,
            sortCurr: -1,
            tagCurr: -1,
            sortName: "服务",
            tagName: "技师",
            list: [],
            page: 1,
            isbottom: !1
        });}
        d.freshData(d)
    },
    sort: function() {
        var shadow = !this.data.sort_list
        this.setData({
            sort_list: !this.data.sort_list,
            tag_list: !1,
            shadow:shadow
        });
    },
    sortChoose: function(t) {
        var d = this, e = t.currentTarget.dataset.index;
        if ( e == d.data.sortCurr) {
            d.setData({shadow:!1,sort_list: !1,})
            return
        }
        d.setData({
            sort_list: !1,
            shadow:!1,
            sortCurr: e,
            sortName: d.data.class[e].name,
            curr: 1,
            list: [],
            page: 1,
            isbottom: !1
        })
        d.freshData(d)
    },
    tag: function() {
        var shadow = !this.data.tag_list
        this.setData({
            tag_list: !this.data.tag_list,
            sort_list: !1,
            shadow:shadow
        });
    },
    tagChoose: function(t) {
        var d = this, e = t.currentTarget.dataset.index;
        if ( e == d.data.tagCurr) {
            d.setData({shadow:!1,tag_list: !1,})
            return
        }
        d.setData({
            tag_list: !1,
            tagCurr: e,
            shadow:!1,
            tagName: d.data.member[e].name,
            curr: 2,
            list: [],
            page: 1,
            isbottom: !1
        })
        d.freshData(d)
    },
    date_choose: function(a) {
        var d = this, t = a.currentTarget.dataset.index;
        if (1== d.data.type && t != d.data.date_curr) {
            d.setData({
                date_curr: t,
                list: [],
                page: 1,
                isbottom: !1,
                sort_list: !1,
                tag_list: !1,
            });
            d.fetch_order_list(d)
        }
        if (2== d.data.type && t != d.data.date_curr){
            d.setData({ date_curr: t})
            get_time(d)
        }
    },

    fetch_order_list: function(d) {
        var cid = (-1 == d.data.sortCurr) ? -1 : d.data.class[d.data.sortCurr].id;
        var mid =  (0 == d.data.owner && -1 != d.data.tagCurr) ? d.data.member[d.data.tagCurr].id : -1;
        var s = {
            op: "online",
            owner: d.data.owner,
            cid:cid,
            mid:mid,
            page: d.data.page,
            pagesize: d.data.pagesize,
            plan_date: d.data.date[d.data.date_curr].date
        };
        "" != d.data.id && null != d.data.id && (s.id = d.data.id), app.util.request({
            url: "entry/wxapp/manage",
            data: s,
            success: function(a) {
                var t = a.data;
                if(1== d.data.owner && ""!= t && ""!= t.data.list){
                    for (var i in t.data.list){
                        t.data.list[i].userinfo.mobile =  t.data.list[i].userinfo.mobile.substr(0,2)+"*****"+ t.data.list[i].userinfo.mobile.substr(7)
                    }
                }
                "" != t.data ? ("" != t.data.store && null != t.data.store && d.setData({
                    store: t.data.store,
                    id: t.data.store.id
                }), "" != t.data.online && null != t.data.online && d.setData({
                    online: t.data.online
                }), "" != t.data.list && null != t.data.list ? d.setData({
                    list: t.data.list,
                    page: d.data.page + 1
                }) : d.setData({
                    isbottom: !0
                })) : d.setData({
                    isbottom: !0
                });
            }
        });
    },

    date_left: function() {
        var e = this;
        if (0 < e.data.date_curr) e.setData({
            date_curr: e.data.date_curr - 1,
            time_curr: -1
        }); else {
            var a = e.data.date;
            if (0 < a[e.data.date_curr].index) (t = {}).index = a[e.data.date_curr].index - 1, 
            t.date = GetDateStr(t.index), t.week = getMyDay(t.index), 0 == t.index ? t.name = "今天" : t.name = getMyDay2(t.index), 
            a.splice(a.length - 1, 1), a.unshift(t), e.setData({
                date: a,
                time_curr: -1
            });
        }
        e.setData({
            list: [],
            page: 1,
            isbottom: !1
        });
        var t = {
            op: "online",
            owner: e.data.owner,
            page: e.data.page,
            pagesize: e.data.pagesize,
            plan_date: e.data.date[e.data.date_curr].date
        };
        "" != e.data.id && null != e.data.id && (t.id = e.data.id), app.util.request({
            url: "entry/wxapp/manage",
            data: t,
            success: function(a) {
                var t = a.data;
                "" != t.data ? ("" != t.data.store && null != t.data.store && e.setData({
                    store: t.data.store,
                    id: t.data.store.id
                }), "" != t.data.online && null != t.data.online && e.setData({
                    online: t.data.online
                }), "" != t.data.list && null != t.data.list ? e.setData({
                    list: t.data.list,
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                })) : e.setData({
                    isbottom: !0
                });
            }
        });
    },
    date_right: function() {
        var e = this;
        if (e.data.date_curr < e.data.date.length - 1) e.setData({
            date_curr: e.data.date_curr + 1,
            time_curr: -1
        }); else {
            var a = e.data.date;
            (t = {}).index = a[e.data.date_curr].index + 1, t.date = GetDateStr(t.index), t.week = getMyDay(t.index), 
            0 == t.index ? t.name = "今天" : t.name = getMyDay2(t.index), a.splice(0, 1), a.push(t), 
            e.setData({
                date: a,
                time_curr: -1
            });
        }
        e.setData({
            list: [],
            page: 1,
            isbottom: !1
        });
        var t = {
            op: "online",
            owner: e.data.owner,
            page: e.data.page,
            pagesize: e.data.pagesize,
            plan_date: e.data.date[e.data.date_curr].date
        };
        "" != e.data.id && null != e.data.id && (t.id = e.data.id), app.util.request({
            url: "entry/wxapp/manage",
            data: t,
            success: function(a) {
                var t = a.data;
                "" != t.data ? ("" != t.data.store && null != t.data.store && e.setData({
                    store: t.data.store,
                    id: t.data.store.id
                }), "" != t.data.online && null != t.data.online && e.setData({
                    online: t.data.online
                }), "" != t.data.list && null != t.data.list ? e.setData({
                    list: t.data.list,
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                })) : e.setData({
                    isbottom: !0
                });
            }
        });
    },
    qie: function() {
        var e = this;
        -1 != e.data.id && (e.setData({
            store_page: !0,
            store_list: []
        }), app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "store"
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && e.setData({
                    store_list: t.data
                });
            }
        }));
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(a) {
        var e = this, t = a.currentTarget.dataset.index;
        e.setData({
            id: e.data.store_list[t].id,
            store_page: !1,
            page: 1,
            isbottom: !1,
            list: [],
            store: ""
        });
        var d = {
            op: "online",
            owner: e.data.owner,
            page: e.data.page,
            pagesize: e.data.pagesize,
            plan_date: e.data.date[e.data.date_curr].date
        };
        "" != e.data.id && null != e.data.id && (d.id = e.data.id), app.util.request({
            url: "entry/wxapp/manage",
            data: d,
            success: function(a) {
                var t = a.data;
                "" != t.data ? ("" != t.data.store && null != t.data.store && e.setData({
                    store: t.data.store,
                    id: t.data.store.id
                }), "" != t.data.online && null != t.data.online && e.setData({
                    online: t.data.online
                }), "" != t.data.list && null != t.data.list ? e.setData({
                    list: t.data.list,
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                })) : e.setData({
                    isbottom: !0
                });
            }
        });
    },
    menu_on: function(a) {
        var t = a.currentTarget.dataset.index;
        this.setData({
            menu: !0,
            shadow: !0,
            curr: t
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow: !1
        });
    },
    call: function(a) {
        var t = a.currentTarget.dataset.index;
        wx.makePhoneCall({
            phoneNumber: this.data.list[t].userinfo.mobile
        });
    },
    submit: function() {
        var t = this, e = t.data.list;
        1 == e[t.data.curr].status && -1 == e[t.data.curr].use && wx.showModal({
            title: "提示",
            content: "确定核销吗？",
            success: function(a) {
                a.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "order_change",
                        id: e[t.data.curr].id
                    },
                    success: function(a) {
                        "" != a.data.data && (e[t.data.curr].is_use = parseInt(e[t.data.curr].is_use) + 1, 
                        e[t.data.curr].is_use == parseInt(e[t.data.curr].can_use) && (e[t.data.curr].use = 1), 
                        t.setData({
                            list: e
                        }), wx.showToast({
                            title: "核销成功",
                            icon: "success",
                            duration: 2e3
                        }));
                    }
                }) : a.cancel && console.log("用户点击取消");
            }
        });
    },
    online: function(a) {
        var t = this, e = t.data.online, d = "";
        -1 == e ? d = "确定关闭预约吗？" : 1 == e && (d = "确定开启预约吗？"), wx.showModal({
            title: "提示",
            content: d,
            success: function(a) {
                a.confirm ? app.util.request({
                    url: "entry/wxapp/manage",
                    data: {
                        op: "online_status",
                        store: t.data.id,
                        status: -t.data.online,
                        plan_date: t.data.date[t.data.date_curr].date
                    },
                    success: function(a) {
                        "" != a.data.data && (1 == e ? wx.showToast({
                            title: "开启成功",
                            icon: "success",
                            duration: 2e3
                        }) : wx.showToast({
                            title: "关闭成功",
                            icon: "success",
                            duration: 2e3
                        }), t.setData({
                            online: -t.data.online
                        }));
                    }
                }) : a.cancel && console.log("用户点击取消");
            }
        });
    },
    onLoad: function(a) {
        var d = this;
        common.config(d), common.theme(d), null != a.store_id && "" != a.store_id && d.setData({
            store_id: a.store_id
        });
        a.owner && d.setData({owner: a.owner})
        for (var t = [], i = 0; i < 5; i++) {
            (s = {}).index = i, s.date = GetDateStr(i), s.week = getMyDay(i), s.name = 0 == i ? "今天" : getMyDay2(i),
            t.push(s);
        }
        var s, n = -1;
        undefined != app.map && "" != app.map && null != app.map && "" != app.map.content && null != app.map.content && 1 == app.map.content.store && (n = ""),
        d.setData({
            date: t,
            map: (undefined!=app.map ? app.map :""),
            id: n
        })
        var n = d.data.config, o = 1, m = 1;
        "" != n && null != n && ("" != n.home_status && null != n.home_status && (o = n.home_status),
        "" != n.online_time && null != n.online_time && (m = n.online_time)), d.setData({
            home_status: o,
            online_time: m
        })
        "" != app.globalData.userInfo.shop_emp && d.setData({member_id: app.globalData.userInfo.shop_emp})
        app.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "pclass"
            },
            success: function(t) {
                var a = t.data.data;
                if ("" != a) {
                    var e = -1;
                    if (null != s.cid && null != s.cid) {
                        for (var r = 0; r < a.length; r++) a[r].id == s.cid && (e = r);
                        d.setData({
                            sortCurr: e,
                            sortName: a[e].name,
                            curr: 1,
                            list: [],
                            page: 1,
                            isbottom: !1
                        });
                    }
                    d.setData({
                        class: a
                    });
                }
            }
        });
    },
    loadServices: function (d) {
        var s = {
            op: "online",
            owner: d.data.owner,
            page: d.data.page,
            pagesize: d.data.pagesize,
            plan_date: d.data.date[d.data.date_curr].date
        }
        //id = a.store_id
        app.util.request({
            url: "entry/wxapp/manage",
            data: s,
            success: function (a) {
                var t = a.data;
                if(1== d.data.owner && ""!= t && ""!= t.data.list){
                    for (var i in t.data.list){
                        t.data.list[i].userinfo.mobile =  t.data.list[i].userinfo.mobile.substr(0,2)+"*****"+ t.data.list[i].userinfo.mobile.substr(7)
                    }
                }
                "" != t.data ? ("" != t.data.store && null != t.data.store && d.setData({
                    store: t.data.store,
                    id: t.data.store.id
                }),
                "" != t.data.online && null != t.data.online && d.setData({
                    online: t.data.online
                }),
                "" != t.data.list && null != t.data.list ? d.setData({
                    list: t.data.list,
                    page: d.data.page + 1,
                    isbottom: !0
                }) : d.setData({
                    list:[],
                    isbottom: !0
                })) : d.setData({
                    list:[],
                    isbottom: !0
                });
                "" != t.data.times && null != t.data.times && (d.setData({ times: t.data.times }))
                "" != t.data.member && null != t.data.member && (d.setData({ member: t.data.member }))
                //"" != t.data && "" != t.data.store && null != t.data.store && wx.setNavigationBarTitle({
                //    title: t.data.store.name
                //});

            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var d = this
        d.setData({page:1})
        d.loadServices(d)
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    new_order: function(a) {
        var d = this
        wx.navigateTo({
            url: "../store/porder1?&store_id=" + d.data.store_id+"&out_trade_no=-1&oid=-1&clone=2"
        });
    },
    set_order: function(a) {
        var d = this, t = a.currentTarget.dataset.index;
        wx.navigateTo({
            url: "../store/porder1?&store_id=" + d.data.store_id+"&out_trade_no="+d.data.list[t]['out_trade_no']+"&oid="+d.data.list[t]['id']
        });
    },
    add_order: function(a) {
        var d = this, t = a.currentTarget.dataset.index;
        wx.navigateTo({
            url: "../store/porder1?&store_id=" + d.data.store_id+"&out_trade_no="+d.data.list[t]['out_trade_no']+"&oid="+d.data.list[t]['id']+"&clone=1"
        });
    },
    onReachBottom: function() {
        var e = this;
        if (!e.data.isbottom) {
            var a = {
                op: "online",
                owner: e.data.owner,
                page: e.data.page,
                pagesize: e.data.pagesize,
                plan_date: e.data.date[e.data.date_curr].date
            };
            "" != e.data.id && null != e.data.id && (a.id = e.data.id), app.util.request({
                url: "entry/wxapp/manage",
                data: a,
                success: function(a) {
                    var t = a.data;
                    "" != t.data ? ("" != t.data.store && null != t.data.store && e.setData({
                        store: t.data.store,
                        id: t.data.store.id
                    }), "" != t.data.online && null != t.data.online && e.setData({
                        online: t.data.online
                    }), "" != t.data.list && null != t.data.list ? e.setData({
                        list: e.data.list.concat(t.data.list),
                        page: e.data.page + 1
                    }) : e.setData({
                        isbottom: !0
                    })) : e.setData({
                        isbottom: !0
                    });
                }
            });
        }
    }
});
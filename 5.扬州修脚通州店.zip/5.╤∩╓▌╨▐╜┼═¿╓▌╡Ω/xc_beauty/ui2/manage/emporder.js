var app = getApp(), common = require("../common/common.js");

var now = new Date(); //当前日期
var nowDayOfWeek = now.getDay(); //今天本周的第几天
var nowDay = now.getDate(); //当前日
var nowMonth = now.getMonth(); //当前月
var nowYear = now.getYear(); //当前年
nowYear += (nowYear < 2000) ? 1900 : 0; //有2100问题
//var currentHours = now.getHours();//当前小时
//var currentMinute = now.getMinutes();//当前分钟`

var lastMonthDate = new Date(); //上月日期
lastMonthDate.setDate(1);
lastMonthDate.setMonth(lastMonthDate.getMonth()-1);
var lastYear = lastMonthDate.getYear();
var lastMonth = lastMonthDate.getMonth();


//格式化日期：yyyy-MM-dd
function formatDate(date) {
    var myyear = date.getFullYear();
    var mymonth = date.getMonth()+1;
    var myweekday = date.getDate();
    if(mymonth < 10){
        mymonth = "0" + mymonth;
    }
    if(myweekday < 10){
        myweekday = "0" + myweekday;
    }
    return (myyear+"-"+mymonth + "-" + myweekday);
}


////获得本月的开始日期
//function getMonthStartDate(){
//    var monthStartDate = new Date(nowYear, nowMonth, 1);
//    return formatDate(monthStartDate);
//}

//获得本月的结束日期
//function getMonthEndDate(){
//    var monthEndDate = new Date(nowYear, nowMonth, getMonthDays(nowMonth));
//    return formatDate(monthEndDate);
//}

//获得某月的天数
//function getMonthDays(myMonth){
//    var monthStartDate = new Date(nowYear, myMonth, 1);
//    var monthEndDate = new Date(nowYear, myMonth + 1, 1);
//    var days = (monthEndDate - monthStartDate)/(1000 * 60 * 60 * 24);
//    return days;
//}

function member_search(e) {
    var a = {
        op: "emp_order",
        page: e.data.page,
        pagesize: e.data.pagesize,
        id: e.data.id,
        openid: e.data.openid,
        curr: e.data.curr
    };
    1 == e.data.curr && (a.search = e.data.search), app.util.request({
        url: "entry/wxapp/order",
        data: a,
        success: function(a) {
            var t = a.data;
            "" != t.data ? e.setData({
                list: e.data.list.concat(t.data.order),
                page: e.data.page + 1
            }) : e.setData({
                isbottom: !0
            });
        }
    });
}

Page({
    data: {
        page: 1,
        search:"",
        pagesize: 10, //大于10
        isbottom: !1,
        list: [],
        /** swiper   **/
        //imageBannerLists: {},
        isSelect: 1,
        winHeight:"",//窗口高度
        currentTab:0, //预设当前项的值
        scrollLeft:0, //tab标题的滚动条位置
        dateFrom:'',
        dateTo:'',
        countOrder:"",
        countAmount: "",
        //startDate: "请选择日期",
        //multiArray: [['今天', '明天', '3-2', '3-3', '3-4', '3-5'], [0, 1, 2, 3, 4, 5, 6], [0, 10, 20]],
        //multiIndex: [0, 0, 0],

    },
    onLoad: function(t) {
        console.log('emporder onload')
        //console.log(t.cht);
        var e = this;
        var tt = new app.util.date()
        e.setData({
            name: t.ename,
            //dateTo:formatDate(now),
            dateTo:tt.dateToStr("yyyy-MM-dd"),
            dateFrom:tt.getMonthStartDate(now),
            empid: t.empid,
            id: t.id,
        });
        console.log(e.data.name)
        common.config(e), common.theme(e),
        wx.setNavigationBarTitle({ title: e.data.name })
        this.fetchData(t);
    },
    fetchData:function(t){
        var e=this
        app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "emp_order",
                //openid: t.openid,
                empid: e.data.empid,
                store: e.data.id,
                curr: e.data.curr,
                dateTo:e.data.dateTo,
                dateFrom:e.data.dateFrom,
                page: e.data.page,
                pagesize: e.data.pagesize,
            },
            success: function(t) {
                var a = t.data;
                //console.log("onload.... op=order curr="+e.data.curr)
                console.log(a)
                if ("" != a.data) {
                    for (var i = 0; i < a.data.length; i++) -1 == a.data[i].status && (a.data[i].hour = parseInt(a.data[i].fail / 3600),
                        a.data[i].min = parseInt((a.data[i].fail - 3600 * a.data[i].hour) / 60), a.data[i].second = a.data[i].fail % 60);
                    e.setData({
                        list: e.data.list.concat(a.data.order),
                        //list: a.data.order,
                        page: e.data.page + 1,
                        countOrder: a.data.sum[0],
                        countAmount: a.data.sum[1],
                        //openid: copenid,
                    })
                    //intervalStart(e)

                } else e.setData({
                    isbottom: !0
                });
            }
        });
    },
    bindDate1Change: function(ex) {
        var e = this
        e.setData({ page: 1,list:[]})
        var tt = new app.util.date()
        console.log(tt.getMonthEndtDate(ex.detail.value));
        if(ex.detail.value != e.data.dateFrom){
            e.setData({dateFrom:ex.detail.value,  'dateTo': tt.getMonthEndtDate(ex.detail.value) })
        }
        e.fetchData()
    },
    bindDate2Change: function(ex) {
        //this.setData({'dateTo':ex.detail.value})
        this.setData({dateTo:ex.detail.value, page: 1,list:[]})
        e.fetchData()
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.isbottom || this.fetchData();
    },

    //
    //pickerTap:function() {
    //    date = new Date();
    //
    //    var monthDay = ['今天','明天'];
    //    var hours = [];
    //    var minute = [];
    //
    //    currentHours = date.getHours();
    //    currentMinute = date.getMinutes();
    //
    //    // 月-日
    //    for (var i = 2; i <= 28; i++) {
    //        var date1 = new Date(date);
    //        date1.setDate(date.getDate() + i);
    //        var md = (date1.getMonth() + 1) + "-" + date1.getDate();
    //        monthDay.push(md);
    //    }
    //
    //    var data = {
    //        multiArray: this.data.multiArray,
    //        multiIndex: this.data.multiIndex
    //    };
    //
    //    if(data.multiIndex[0] === 0) {
    //        if(data.multiIndex[1] === 0) {
    //            this.loadData(hours, minute);
    //        } else {
    //            this.loadMinute(hours, minute);
    //        }
    //    } else {
    //        this.loadHoursMinute(hours, minute);
    //    }
    //
    //    data.multiArray[0] = monthDay;
    //    data.multiArray[1] = hours;
    //    data.multiArray[2] = minute;
    //
    //    this.setData(data);
    //},

    //bindMultiPickerColumnChange:function(e) {
    //    date = new Date();
    //
    //    var that = this;
    //
    //    var monthDay = ['今天', '明天'];
    //    var hours = [];
    //    var minute = [];
    //
    //    currentHours = date.getHours();
    //    currentMinute = date.getMinutes();
    //
    //    var data = {
    //        multiArray: this.data.multiArray,
    //        multiIndex: this.data.multiIndex
    //    };
    //    // 把选择的对应值赋值给 multiIndex
    //    data.multiIndex[e.detail.column] = e.detail.value;
    //
    //    // 然后再判断当前改变的是哪一列,如果是第1列改变
    //    if (e.detail.column === 0) {
    //        // 如果第一列滚动到第一行
    //        if (e.detail.value === 0) {
    //
    //            that.loadData(hours, minute);
    //
    //        } else {
    //            that.loadHoursMinute(hours, minute);
    //        }
    //
    //        data.multiIndex[1] = 0;
    //        data.multiIndex[2] = 0;
    //
    //        // 如果是第2列改变
    //    } else if (e.detail.column === 1) {
    //
    //        // 如果第一列为今天
    //        if (data.multiIndex[0] === 0) {
    //            if (e.detail.value === 0) {
    //                that.loadData(hours, minute);
    //            } else {
    //                that.loadMinute(hours, minute);
    //            }
    //            // 第一列不为今天
    //        } else {
    //            that.loadHoursMinute(hours, minute);
    //        }
    //        data.multiIndex[2] = 0;
    //
    //        // 如果是第3列改变
    //    } else {
    //        // 如果第一列为'今天'
    //        if (data.multiIndex[0] === 0) {
    //
    //            // 如果第一列为 '今天'并且第二列为当前时间
    //            if(data.multiIndex[1] === 0) {
    //                that.loadData(hours, minute);
    //            } else {
    //                that.loadMinute(hours, minute);
    //            }
    //        } else {
    //            that.loadHoursMinute(hours, minute);
    //        }
    //    }
    //    data.multiArray[1] = hours;
    //    data.multiArray[2] = minute;
    //    this.setData(data);
    //},
    //
    //loadData: function (hours, minute) {
    //
    //    var minuteIndex;
    //    if (currentMinute > 0 && currentMinute <= 10) {
    //        minuteIndex = 10;
    //    } else if (currentMinute > 10 && currentMinute <= 20) {
    //        minuteIndex = 20;
    //    } else if (currentMinute > 20 && currentMinute <= 30) {
    //        minuteIndex = 30;
    //    } else if (currentMinute > 30 && currentMinute <= 40) {
    //        minuteIndex = 40;
    //    } else if (currentMinute > 40 && currentMinute <= 50) {
    //        minuteIndex = 50;
    //    } else {
    //        minuteIndex = 60;
    //    }
    //
    //    if (minuteIndex == 60) {
    //        // 时
    //        for (var i = currentHours + 1; i < 24; i++) {
    //            hours.push(i);
    //        }
    //        // 分
    //        for (var i = 0; i < 60; i += 10) {
    //            minute.push(i);
    //        }
    //    } else {
    //        // 时
    //        for (var i = currentHours; i < 24; i++) {
    //            hours.push(i);
    //        }
    //        // 分
    //        for (var i = minuteIndex; i < 60; i += 10) {
    //            minute.push(i);
    //        }
    //    }
    //},
    //
    //loadHoursMinute: function (hours, minute){
    //    // 时
    //    for (var i = 0; i < 24; i++) {
    //        hours.push(i);
    //    }
    //    // 分
    //    for (var i = 0; i < 60; i += 10) {
    //        minute.push(i);
    //    }
    //},
    //
    //loadMinute: function (hours, minute) {
    //    var minuteIndex;
    //    if (currentMinute > 0 && currentMinute <= 10) {
    //        minuteIndex = 10;
    //    } else if (currentMinute > 10 && currentMinute <= 20) {
    //        minuteIndex = 20;
    //    } else if (currentMinute > 20 && currentMinute <= 30) {
    //        minuteIndex = 30;
    //    } else if (currentMinute > 30 && currentMinute <= 40) {
    //        minuteIndex = 40;
    //    } else if (currentMinute > 40 && currentMinute <= 50) {
    //        minuteIndex = 50;
    //    } else {
    //        minuteIndex = 60;
    //    }
    //
    //    if (minuteIndex == 60) {
    //        // 时
    //        for (var i = currentHours + 1; i < 24; i++) {
    //            hours.push(i);
    //        }
    //    } else {
    //        // 时
    //        for (var i = currentHours; i < 24; i++) {
    //            hours.push(i);
    //        }
    //    }
    //    // 分
    //    for (var i = 0; i < 60; i += 10) {
    //        minute.push(i);
    //    }
    //},
    //
    //bindStartMultiPickerChange: function (e) {
    //    var that = this;
    //    var monthDay = that.data.multiArray[0][e.detail.value[0]];
    //    var hours = that.data.multiArray[1][e.detail.value[1]];
    //    var minute = that.data.multiArray[2][e.detail.value[2]];
    //
    //    if (monthDay === "今天") {
    //        var month = date.getMonth()+1;
    //        var day = date.getDate();
    //        monthDay = month + "月" + day + "日";
    //    } else if (monthDay === "明天") {
    //        var date1 = new Date(date);
    //        date1.setDate(date.getDate() + 1);
    //        monthDay = (date1.getMonth() + 1) + "月" + date1.getDate() + "日";
    //
    //    } else {
    //        var month = monthDay.split("-")[0]; // 返回月
    //        var day = monthDay.split("-")[1]; // 返回日
    //        monthDay = month + "月" + day + "日";
    //    }
    //
    //    var startDate = monthDay + " " + hours + ":" + minute;
    //    that.setData({
    //        startDate: startDate
    //    })
    //},



  //
});




var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: -1,
        //noauth:1,
        list:[]
    },
    tab: function(t) {
        var n = this, a = t.currentTarget.dataset.index;
        a != n.data.curr && (n.setData({
            curr: a,
            list: []
        }), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                ct:2,
                curr: n.data.curr
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && 1!= a.data.noauth && n.setData({
                    list: a.data,
                    noauth:0
                });
                "" != a.data && 1== a.data.noauth && n.setData({
                    noauth:1
                });
            }
        }));
    },
    reload:function(t){
        var n=this
        var ct= t ? t : 1;
        var i=setInterval(function(){
            //console.log("setinterval..ct:"+ct)
            wx.getStorage({//获取本地缓存
                key:"userInfo",
                success:function(res){
                    app.util.request({
                        url: "entry/wxapp/index",
                        data: {
                            op: "coupon",
                            ct:ct,
                            curr: n.data.curr
                        },
                        success: function(t1) {
                            var a = t1.data;
                            var noauth =  a.data.noauth ?  a.data.noauth : -1;
                            "" != a.data && 1!=a.data.noauth && n.setData({
                                list: a.data,
                            });
                        },
                    });
                    clearInterval(i)
                },
            })
        },1500)
        setTimeout(function(){
            clearInterval(i)
        },30000)
    },
    onLoad: function(t) {
        var n = this;
        common.config(n), common.theme(n)
        if (undefined == t || undefined == t.ct || null == t) {
            var t = null
            //common.login(n),
            app.util.request({
                url: "entry/wxapp/index",
                data: {
                    op: "base"
                },
                showLoading: !1,
                success: function (e) {
                    var a = e.data, n = 1;
                    var baseurl = e.data.data.theme.content.homepage;
                    "" != a.data && ("" != a.data.config && null != a.data.config && (app.config = a.data.config),
                    "" != a.data.theme && null != a.data.theme && (app.theme = a.data.theme, "" != a.data.theme.content && null != a.data.theme.content && 3 == a.data.theme.content.theme && (n = 3)),
                    "" != a.data.map && null != a.data.map && (app.map = a.data.map), "" != a.data.share && null != a.data.share && (app.share = a.data.share));
                }
            })
        }
        var ct = ( undefined == t || undefined == t.ct || null == t ) ? -1 : t.ct;
        app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                ct:ct,
                curr: n.data.curr
            },
            success: function(t1) {
                var a = t1.data;
                var noauth =  a.data.noauth ?  a.data.noauth : -1;
                "" != a.data && 1!=a.data.noauth && n.setData({
                    list: a.data,
                });
                if ( "503-Auth"==a.message ){
                    n.reload(ct)
                }
            },
        });

    },
    toService: function(t) {
        if (1==t.currentTarget.dataset.isexp) {
            wx.showToast({
              title: '已经过期了',icon: "success",duration: 850
            })
            return
        }

        wx.navigateTo({
          url: "../../ui2/service/service"
        })
    },
    toHome: function() {
        wx.redirectTo({
            url: "../../ui2/index/index"
        })
    },
    onReady: function() {},
    onShow: function() {this.onLoad({ct:1})},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
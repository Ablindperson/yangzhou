var app = getApp(), common = require("../common/common.js");

function member_search(e) {
    //console.log('member_search')
    //console.log('e.data.curr:'+e.data.curr)
    var fetchpage= 0
    var fetchcurr= 0

    1==e.data.all?fetchpage=0:(0== e.data.currentTab?fetchpage= e.data.page:fetchpage= e.data.page2)
    0==e.data.currentTab?fetchcurr= 2:fetchcurr= 1
    var a = {
        op: "member_search",
        page: fetchpage,
        pagesize: e.data.pagesize,
        id: e.data.id,
        curr: fetchcurr,
        all: e.data.all,
    };
    //1 == e.data.curr && (a.search = e.data.search),
    a.search = e.data.search,
    undefined==a.search && (a.search=""),
    app.util.request({
        url: "entry/wxapp/manage",
        data: a,
        success: function(a) {
            var t = a.data;
            if( "" != t.data ) {
                //console.log(t.data)
                //console.log('all:'+e.data.all)
                if (1== e.data.all){
                    e.setData({
                        list2: e.data.list.concat(t.data[1]),
                        list: e.data.list.concat(t.data[0]),
                        page: e.data.page + 1,
                        page2: e.data.page2 + 1,
                        all: 0,
                    })
                }else{
                    // currentTab 1 会员 0 非会员
                    if (1==e.data.currentTab){
                        //console.log('currentTab==1')
                        e.setData({
                            list2: e.data.list2.concat(t.data),
                            page2: e.data.page2 + 1,
                        })
                    }else{
                        //console.log('currentTab!=1 : '+e.data.currentTab)
                        e.setData({
                            list: e.data.list.concat(t.data),
                            page: e.data.page + 1,
                        })
                    }
                }
                //console.log('search_success');
            }else{
                // 没有更多数据了
                (0==e.data.currentTab) && e.setData({ isbottom: !0 });
                (1==e.data.currentTab) && e.setData({ isbottom2: !0 });
            }
        },
        fail:function(){
            //console.log('search_fail');
        }
    });
}

Page({
    data: {

        search:"",
        pagesize: 20,
        page: 1,
        list: [],
        isbottom: !1,
        page2: 1,
        list2: [],
        isbottom2: !1,
        /** swiper   **/
        //imageBannerLists: {},
        isSelect: 1,
        winHeight:"",//窗口高度
        currentTab:0, //预设当前项的值
        scrollLeft:0, //tab标题的滚动条位置
    },
    input: function(a) {
        this.setData({
            search: a.detail.value
        });
    },
    consume:function(a){
        //console.log('consume')
        //console.log(a)
        "" != a && null != a ? wx.navigateTo({
            url: "../store_manager/consume?&curr=1&id=" + this.data.store_id+"&openid="+a.currentTarget.dataset.index
        }) : wx.showModal({
            title: "错误",
            content: "testing"
        });
    },
    clearinput:function(){
        var a=this
        a.setData({search:""})
    },
    submit: function() {
        var a = this, t = a.data.search;
        //console.log(t);
        "" != t && null != t ? (a.setData({
            list: [],
            page: 1,
            isbottom: !1
        }), member_search(a)) : wx.showModal({
            title: "错误", 
            content: "请输入手机号"
        });
    },
    call: function(a) {
        var t = a.currentTarget.dataset.index;
        wx.makePhoneCall({
            phoneNumber: this.data.list[t].mobile
        });
    },
    phonesearch: function() {
        var e = this
        var a = this.data
        var fetchcurr= 0
        0==a.currentTab?fetchcurr= 2:fetchcurr= 1
        var fetchall = 0;
        (""==a.search || undefined==a.search) ? fetchall=1 : fetchall=a.all;

        (0==a.currentTab) && e.setData({ curr:2,isbottom: 0,page:1,list:[] });
        (1==a.currentTab) && e.setData({ curr:1,isbottom2: 0,page2:1,list2:[] });

        member_search(e);
        //wx.navigateTo({
        //    url: "../store_manager/member?&curr="+fetchcurr+"&all="+ fetchall+"&search=" + a.search + "&id=" + a.store_id
        //})
        //: wx.showModal({ title: "错误", content: "请输入手机号" });
        //if (undefined != a.search && ""!= a.search ){

        //}else{
        //    (0==a.currentTab) && e.setData({ curr:2,isbottom: 0 });
        //    (1==a.currentTab) && e.setData({ curr:1,isbottom2: 0 });
        //}

    },
    onLoad: function(a) {
        //console.log('member onload:')
        var t = this;
        common.config(t), common.theme(t), t.setData({
            store_id: a.id,
            id: a.id,
            curr: a.curr,
            all: a.all,
        }),
        1 == a.curr && t.setData({
            currentTab:1,
            search: a.search
        }),
        app.util.request({
            url: "entry/wxapp/manage",
            data: {
                op: "store_detail",
                id: a.id,
            },
            success: function(a) {
                var d = a.data;
                //console.log(d);
                "" != d.data && "" != d.data.store && null != d.data.store && wx.setNavigationBarTitle({
                    title: d.data.store.name
                }) ;
                t.setData({
                    store: d.data.store
                })
            }
        }),
        member_search(t);
        //计算屏高
        wx.getSystemInfo( {
            success: function( res ) {
                var clientHeight=res.windowHeight,
                    clientWidth=res.windowWidth,
                    rpxR=750/clientWidth;
                var  calc=clientHeight*rpxR-180;
                //console.log(calc)
                t.setData( {
                    winHeight: calc
                });
            }
        });

    },

    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.isbottom || member_search(this);
    },

    /* swiper */
    //imageBanner: new ImageBannerLists(),
    /**
     * 生命周期函数--监听页面加载
     */
    //onLoad: function (options) {
    //    var myArray = [], length = 20;
    //    for(var i = 0; i < length; i++) {
    //        myArray[i] = i + 1;
    //    }
    //    console.log(myArray);
    //
    //    this.setData({
    //        imageBannerLists: this.imageBanner.imageBanner,
    //        blogLists: myArray
    //    });
    //},
    /**
     * 监听
     */
    //changeTab: function(e){
    //    console.log("changeTab");
    //    var isSelect = e.currentTarget.dataset.type;
    //    this.setData({
    //        isSelect: isSelect
    //    })
    //},
    //swiperChange: function(e) {
    //    console.log("swiperChange");
    //    console.log(e);
    //    this.setData({
    //        isSelect: e.detail.current
    //    })
    //},
    //pushPersonCenter: function() {
    //    wx.navigateTo({
    //        url: '../person-center/index'
    //    })
    //},

    // 滚动切换标签样式
    switchTab:function(e){
        this.setData({
            currentTab:e.detail.current
        });
        this.checkCor();
    },
    // 点击标题切换当前页时改变样式
    swichNav:function(e){
        var cur=e.target.dataset.current;
        if(this.data.currentTaB==cur){return false;}
        else{
            this.setData({
                currentTab:cur
            })
        }
    },
    //判断当前滚动超过一屏时，设置tab标题滚动条。
    checkCor:function(){
        if (this.data.currentTab>4){
            this.setData({
                scrollLeft:300
            })
        }else{
            this.setData({
                scrollLeft:0
            })
        }
    },
    //onLoad: function() {
    //    var that = this;
    //    //  高度自适应
    //    wx.getSystemInfo( {
    //        success: function( res ) {
    //            var clientHeight=res.windowHeight,
    //                clientWidth=res.windowWidth,
    //                rpxR=750/clientWidth;
    //            var  calc=clientHeight*rpxR-180;
    //            console.log(calc)
    //            that.setData( {
    //                winHeight: calc
    //            });
    //        }
    //    });
    //},
    //footerTap:app.footerTap,


    //
});
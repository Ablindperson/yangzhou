var app = getApp(), common = require("../common/common.js");

function member_search(e) {
    var a = {
        op: "consume",
        page: e.data.page,
        pagesize: e.data.pagesize,
        id: e.data.id,
        openid: e.data.openid,
        curr: e.data.curr
    };
    1 == e.data.curr && (a.search = e.data.search), app.util.request({
        url: "entry/wxapp/order",
        data: a,
        success: function(a) {
            var t = a.data;
            "" != t.data ? e.setData({
                list: e.data.list.concat(t.data.order),
                page: e.data.page + 1
            }) : e.setData({
                isbottom: !0
            });
        }
    });
}

Page({
    data: {
        page: 1,
        search:"",
        pagesize: 10, //大于10
        isbottom: !1,
        list: [],
        /** swiper   **/
        //imageBannerLists: {},
        isSelect: 1,
        winHeight:"",//窗口高度
        currentTab:0, //预设当前项的值
        scrollLeft:0, //tab标题的滚动条位置
    },
    onLoad: function(t) {
        //console.log(t);// {}
        //console.log(t.cht);
        var e = this;
        var copenid = t.openid;
        //if (1==t.cht){
        //    e.setData({
        //        curr:2,
        //        page:1
        //    })
        //    //e.data.curr = 2;
        //    //e.data.page = 1;
        //}
        common.config(e), common.theme(e), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "consume",
                openid: t.openid,
                curr: e.data.curr,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(t) {
                var a = t.data;
                //console.log("onload.... op=order curr="+e.data.curr)
                console.log(a)
                if ("" != a.data) {
                    for (var i = 0; i < a.data.length; i++) -1 == a.data[i].status && (a.data[i].hour = parseInt(a.data[i].fail / 3600),
                        a.data[i].min = parseInt((a.data[i].fail - 3600 * a.data[i].hour) / 60), a.data[i].second = a.data[i].fail % 60);
                    e.setData({
                        list: a.data.order,
                        page: e.data.page + 1,
                        openid: copenid,
                    })
                        //intervalStart(e)

                } else e.setData({
                    isbottom: !0
                });
                wx.setNavigationBarTitle({
                    title: a.data.name
                }) ;
                //"" != a.data ? e.setData({
                //    list: a.data,
                //    page: e.data.page + 1
                //}) : e.setData({
                //    isbottom: !0
                //});
            }
        });
    },

    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.isbottom || member_search(this);
    },

    //
});
var app = getApp(), common = require("../common/common.js");
var extend=function(o,n){ for (var p in n){ if(n.hasOwnProperty(p) && (!o.hasOwnProperty(p) ))  o[p]=n[p]; } return o; };
var now = new Date(); //当前日期
var nowDayOfWeek = now.getDay(); //今天本周的第几天
var nowDay = now.getDate(); //当前日
var nowMonth = now.getMonth(); //当前月
var nowYear = now.getYear(); //当前年
nowYear += (nowYear < 2000) ? 1900 : 0; //有2100问题
var currentHours = now.getHours();//当前小时
var currentMinute = now.getMinutes();//当前分钟`

var lastMonthDate = new Date(); //上月日期
lastMonthDate.setDate(1);
lastMonthDate.setMonth(lastMonthDate.getMonth()-1);
var lastYear = lastMonthDate.getYear();
var lastMonth = lastMonthDate.getMonth();
var hs = this


// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "H+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

function GetDateStr(t) {
    var e = new Date();
    e.setDate(e.getDate() + t);
    e.getFullYear();
    return e.getMonth() + 1 + "月" + e.getDate() + "日";
}

function getMyDay(t) {
    var e = new Date();
    return e.setDate(e.getDate() + t), 0 == e.getDay() && "周日", 1 == e.getDay() && "周一", 
    2 == e.getDay() && "周二", 3 == e.getDay() && "周三", 4 == e.getDay() && "周四", 5 == e.getDay() && "周五", 
    6 == e.getDay() && "周六", e.getDay();
}

function getMyDay2(t) {
    var e, a = new Date();
    return a.setDate(a.getDate() + t), 0 == a.getDay() && (e = "周日"), 1 == a.getDay() && (e = "周一"), 
    2 == a.getDay() && (e = "周二"), 3 == a.getDay() && (e = "周三"), 4 == a.getDay() && (e = "周四"), 
    5 == a.getDay() && (e = "周五"), 6 == a.getDay() && (e = "周六"), e;
}

function time_conflict(a,s,t){
    if(!a) return [0,0];
    var e = new Date();
    e.setHours(s.split(":")[0], s.split(":")[1], 0);
    e.setMinutes(e.getMinutes() + parseInt(t),0,0)
    e = e.Format("HH:mm")
    var c = 0,c1 = 0
    for (var i in a){
        if (a[i][1] < "02:00") {
            a[i][1] = a[i][1].replace("00:","24:").replace("01:","25:")
        }
        //console.log(s+'-'+e+' **  '+ a[i][0] +'-'+a[i][1] )
        if (s < a[i][1] && e > a[i][0] ){
            //if (s <= a[i][0]) c = a[i][0];
            //if (e >= a[i][1]) c1 = a[i][1];
            c = a[i][0]; c1 = a[i][1];
            return [c,c1]
        };
    }
    return [c,c1]
}

function get_time(i) {
    var th=this;
    var d = i.data.times, r = [], s = !1;
    i.setData({
        time_list: s,
        tip: s
    }), 1 == i.data.online_time && app.util.request({
        url: "entry/wxapp/user",
        showLoading: !1,
        data: {
            op: "plan_date",
            plan_date: i.data.date[i.data.date_curr].date,
            id: i.data.id
        },
        success: function(t) {
            var e = t.data;
            if ("" != e.data) {
                if (1 == e.data.status) for (var a = 0; a < d.length; a++) d[a].week == i.data.date[i.data.date_curr].week ? r = d[a].content : 7 == d[a].week && 0 == i.data.date[i.data.date_curr].week && (r = d[a].content);
                else s = !0;
                r = check_today_time(new Date(nowYear+'/'+( i.data.date[i.data.date_curr].date) .replace('月','/').replace('日','')),r)
                "" != i.data.member_id && null != i.data.member_id ? app.util.request({
                    url: "entry/wxapp/user",
                    data: {
                        op: "times_log",
                        ot: i.data.order_type,
                        multi: i.data.multi_curr,
                        member: i.data.member_id,
                        plan_date: i.data.date[i.data.date_curr].date,
                        list: JSON.stringify(r),
                        index: i.data.date[i.data.date_curr].index
                    },
                    success: function(t) {
                        var e = t.data;
                        r = ("" != e.data) ? check_today_time(new Date(nowYear+'/'+( i.data.date[i.data.date_curr].date) .replace('月','/').replace('日','')), e.data)
                            : check_today_time(new Date(nowYear+'/'+( i.data.date[i.data.date_curr].date) .replace('月','/').replace('日','')),r);
                        i.setData({
                            tip: s,
                            time_curr: -1,
                            time_list: r
                        });
                        if ( undefined!=i.data.multiOrder && undefined !=i.data.date_curr &&  1 == i.data.multi_curr[i.data.date_curr]
                            && -1!=i.data.multiOrder.indexOf(i.data.date_curr)){
                            i.setData({startTime: i.data.multiStartTime[i.data.date_curr].first})
                            i.protect_time_choose1(i)
                        }
                    }
                }) : i.setData({
                    time_curr: -1,
                    time_list: r,
                    tip: s
                })
                ;
            }
        }
    });
}
function check_today_time(startDate,l){
    //当天最后一条
    var j = l.length - 1;
    if (new Date(startDate).toDateString() === new Date().toDateString()) {  /*今天*/
        var currentHM = new Date().Format("HH:mm");
        //currentHM="22:49"
        currentHM = currentHM>l[0].start?currentHM:l[0].start;
        var cm=currentHM.split(':')[1];
        for (var j in l) {
            if (l[j].start < currentHM || 0==j) {
                if (l[j].end > currentHM) {
                    var b2 = 2048; l[j].now_mask=0;
                    for (var k=0;k<60 && k<cm ;k=k+5) {
                        l[j].now_mask += b2; b2 = b2>>1;
                    }
                } else {
                    l[j].now_mask = 4095;
                }
            }else{
                l[j].now_mask = 0;
            }
        }
    }else{
        var cm = new Date(); b2 = 2048; l[0].now_mask=0;
        cm.setHours(l[0].start.split(":")[0],l[0].start.split(":")[1],0);
        cm=cm.Format("m");
        for (var k=0;k<60 && k<cm ;k=k+5) {
            l[0].now_mask += b2; b2 = b2>>1;
        }
    }
    if (0 != l[j].end.split(':')[1]) { //非整点结束
        var b2 = 2048; l[j].now_mask=0;
        //console.log(l[j].start+' -  '+l[j].end)
        for (var k=0;k<60;k=k+5) {
            if (k >= l[j].end.split(':')[1] ){
                l[j].now_mask += b2;
            }
            b2 = b2>>1;
        }
    }

    return l
}

function sign(t) {
    var e = t.data.time_curr, m= t.data.multi_curr,a = t.data.name, i = (t.data.mobile, t.data.member_id), d = t.data.service_id, r = t.data.service_type, s = "";
    1 == t.data.online_time && ( -1 == e || undefined == t.data.startTime || "" == t.data.startTime) && (s = "请选择时间"), "" != a && null != a || (s = "请填写预约人信息"),
    "" != i && null != i || (s = "请选择服务人员"), "" != d && null != d || (s = "请选择服务项目"), 
    -1 == r && (s = "请选择服务方式"), "" == s ? t.setData({
        submit: !0
    }) : wx.showModal({
        title: "提示",
        showCancel:false,
        content: s
    });
}

function wxpay(a, t) {
    a.appId;
    var o = a.timeStamp.toString(), e = a.package, n = a.nonceStr, d = a.paySign.toUpperCase();
    var redir1 = "../order/order";
    if (t.data.service_home.out_trade_no != undefined) {
        //console.log(t.data.service_home.out_trade_no)
        redir1 = "../order/detail?&out_trade_no=" + t.data.service_home.out_trade_no
    }
    if (3==t.data.order_type) {
        redir1 = "../group/detail?&id=" + t.data.service_home.group;
    }

    //console.log("wxpay::"+redir1);
    wx.requestPayment({
        timeStamp: o,
        nonceStr: n,
        package: e,
        signType: "MD5",
        paySign: d,
        success: function(a) {
            wx.showToast({
                title: "支付成功",
                icon: "success",
                duration: 2e3
            }), setTimeout(function() {
                3 == t.data.order_type ? wx.redirectTo({
                    url: "../group/detail?&id=" + t.data.service_home.group
                }) : wx.redirectTo({
                    url: redir1
                });
            }, 2e3);
        },
        fail: function(a) {
            console.log(a);
        }
    });
}

Page({
    data: {
        pagePath: "../store/porder",
        date_curr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        submit: !1,
        time_curr: -1,
        service_type: -1,
        d_week_rate: -1,
        sid:"",
        pay_type:5,
        coupon_price:"",
        menu:!1,
        multi_arr: [
            '与上一单接受服务顾客为同一人',
            '与上一单接受服务顾客非同一人，同时进店[请预约不同技师]',
            '与上一单接受服务顾客非同一人，非同时进店'
        ],
        multi_curr:[]
    },
    tab: function(t) {
        var e = this, a = (e.data.service_home, t.currentTarget.dataset.index);
        if (undefined != e.data.service_home) {
            var g = e.data.service_home.home;
            if (-1 == g && 1 == a) {
                wx.showModal({
                    title: "提示",
                    showCancel:false,
                    content: "团购暂不支持上门服务"
                });
                return;
            }
        }
        a != e.data.service_type && (1 == a ? e.setData({
            member_id: -2,
            member_name: "店内安排"
        }) : e.setData({
            member_id: null,
            member_name: null
        }), e.setData({
            service_type: a
        }), get_time(e));
    },
    qie: function() {
        var i = this;
        1 == i.data.more_store && -1 != i.data.id && (i.setData({
            store_page: !0,
            store_list: []
        }), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var e = t.latitude, a = t.longitude;
                t.speed, t.accuracy;
                i.setData({
                    latitude: e,
                    longitude: a
                });
            },
            complete: function() {
                var t = {
                    op: "store",
                    page: i.data.page,
                    pagesize: i.data.pagesize
                };
                null != i.data.latitude && "" != i.data.latitude && (t.latitude = i.data.latitude), 
                null != i.data.longitude && "" != i.data.longitude && (t.longitude = i.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/order",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data && (i.setData({
                            store_list: e.data
                        }), get_time(i));
                    }
                });
            }
        }));
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        e.setData({
            list: e.data.store_list[a],
            id: e.data.store_list[a].id,
            store_page: !1
        }), 1 != e.data.service_type && e.setData({
            member_id: ""
        }), get_time(e);
    },
    call: function(t) {
        var e = this;
        null != e.data.id && "" != e.data.id && (-1 == e.data.id ? wx.makePhoneCall({
            phoneNumber: e.data.map.content.mobile
        }) : wx.makePhoneCall({
            phoneNumber: e.data.list.mobile
        }));
    },
    map: function(t) {
        var e = this;
        null != e.data.id && "" != e.data.id && (-1 == e.data.id ? wx.openLocation({
            latitude: parseFloat(e.data.map.content.latitude),
            longitude: parseFloat(e.data.map.content.longitude),
            name: e.data.map.content.address,
            address: e.data.map.content.address,
            scale: 28
        }) : wx.openLocation({
            latitude: parseFloat(e.data.list.map.latitude),
            longitude: parseFloat(e.data.list.map.longitude),
            name: e.data.list.address,
            address: e.data.list.address,
            scale: 28
        }));
    },
    date_choose: function(t) {
        var d = this,a = t.currentTarget.dataset.index;
        if (a != d.data.date_curr){
            var startDate=d.data.date[a]['date']
            var now = new Date(nowYear+'/'+startDate.replace('月','/').replace('日','')+' '+d.data.startTime);
            var newDate = now.setMinutes(now.getMinutes()+parseInt(d.data.service_time));
            newDate = new Date(newDate).Format("MM月dd日 HH:mm");
            d.setData({
                date_curr: a,
                time_curr: -1,
                startDate: d.data.date[a]['date'],
                startTime:"",
                end_time:newDate
            })
            if ( undefined!=d.data.multiOrder && undefined !=d.data.date_curr &&  0 == d.data.multi_curr[d.data.date_curr]
                && -1!=d.data.multiOrder.indexOf(d.data.date_curr)){
                d.setData({startTime: d.data.multiStartTime[d.data.date_curr].end})
                d.protect_time_choose(d)
                return
            }
            get_time(d);
            d.data.service_id && this.calc_amt(d);
        };
        ( undefined!=d.data.multiOrder && undefined !=d.data.date_curr &&  undefined == d.data.multi_curr[d.data.date_curr] && -1!=d.data.multiOrder.indexOf(d.data.date_curr)) &&
        d.setData({multi_page:1});
    },
    date_left: function() {
        var t = this;
        if (0 < t.data.date_curr) t.setData({
            date_curr: t.data.date_curr - 1,
            time_curr: -1
        }), get_time(t); else {
            var e = t.data.date;
            if (0 < e[t.data.date_curr].index) {
                var a = {};
                a.index = e[t.data.date_curr].index - 1, a.date = GetDateStr(a.index), a.week = getMyDay(a.index), 
                0 == a.index ? a.name = "今天" : a.name = getMyDay2(a.index), e.splice(e.length - 1, 1), 
                e.unshift(a), t.setData({
                    date: e,
                    time_curr: -1
                }), get_time(t);
            }
        }
    },
    date_right: function() {
        var t = this;
        if (t.data.date_curr < t.data.date.length - 1) t.setData({
            date_curr: t.data.date_curr + 1,
            time_curr: -1
        }), get_time(t); else {
            var e = t.data.date, a = {};
            a.index = e[t.data.date_curr].index + 1, a.date = GetDateStr(a.index), a.week = getMyDay(a.index), 
            0 == a.index ? a.name = "今天" : a.name = getMyDay2(a.index), e.splice(0, 1), e.push(a), 
            t.setData({
                date: e,
                time_curr: -1
            }), get_time(t);
        }
    },
    /* 所有时间片禁止选择 */
    protect_time_choose:function(d){
        var arr1 = d.data.time_list;
        for(var $i in arr1){
            arr1[$i].status = 2
        }
        d.setData({time_list:arr1, startTime: d.data.multiStartTime[d.data.date_curr].end })
    },
    protect_time_choose1:function(d){
        var arr1 = d.data.time_list,s1 = d.data.multiStartTime[d.data.date_curr].first,m1=d.data.multiStartTime[d.data.date_curr].m
        for(var $i in arr1){
            if( arr1[$i].start <= s1 && s1 < arr1[$i].end ){
                if( -1 != m1.indexOf(d.data.member_id) ){arr1[$i].status = 1;}
            }else{
                arr1[$i].status = 2
            }
        }
        //d.setData({time_list:arr1}); //TODO 待测试
        d.setData({time_list:arr1, startTime: d.data.multiStartTime[d.data.date_curr].first })
    },
    /* 顾客当天多单提示 */
    multi_choose:function(t){
        var d = this;
        var a = t.currentTarget.dataset.index;
        //(undefined == d.data.multi_curr || a != d.data.multi_curr) && d.setData({   multi_curr: a   });
        var arr1=d.data.multi_curr
        arr1[d.data.date_curr]=a
        d.setData({multi_curr:arr1 ,  multi_page:!1})
        0==a && d.protect_time_choose(d)
        1==a && d.protect_time_choose1(d)
    },
    multi_close: function() {
        this.setData({
            multi_page: !1,
        });
    },
    time_choose: function(t) {
        var hs = this;
        var a = t.currentTarget.dataset.index;
        var l = hs.data.time_list[a];
        if ( undefined == hs.data.service_name || "" == hs.data.service_name ) {
            wx.showModal({
                //title: "提示",
                content:"请先选择【服务项目】",
                showCancel:false,
                confirmText:"朕知道了"
            })
            return;
        }
        if ( undefined == hs.data.member_name || "" == hs.data.member_name) {
            wx.showModal({
                //title: "提示",
                content:"请先选择【服务人员】",
                showCancel:false,
                confirmText:"朕知道了"
            })
            return;
        }
        a != hs.data.time_curr && hs.setData({
            time_curr: a
        });

        //上门服务不需要预约时长估算 2018-09-25
        if (1 == hs.data.service_type) return;
        var content = "";
        //特殊处理1
        if ( undefined!=hs.data.multiOrder && undefined !=hs.data.date_curr &&  1 == hs.data.multi_curr[hs.data.date_curr]
            && -1!=hs.data.multiOrder.indexOf(hs.data.date_curr)){
            content ="预约上门服务成功! 预约时间："+ hs.data.multiStartTime[hs.data.date_curr].first;
            if( "" != content ) {
                wx.showModal({
                    title: "提示",
                    content:content,
                    showCancel:false,
                    confirmText:"朕知道了"
                })
            }
            return
        }

        //自动计算到店时间
        var startTime = l.start;
        if(l.div){//已有约，自动找空闲时间  //TODO 要加入冲突检查
            var art = JSON.parse(l.div);
            for(var i in art){
                if (startTime < art[i][1] && startTime >= art[i][0] ){
                    startTime = art[i][1];
                };
            }
        }
        var t = new Date(nowYear+'/'+( hs.data.date[hs.data.date_curr].date) .replace('月','/').replace('日',''));//所选日期
        if (t.toDateString() === new Date().toDateString()) {  //今天
            var x = new Date();
            //var x = new Date('2018/12/06 22:49:59');
            x.setMinutes(x.getMinutes() + 10, 0, 0);//当前时间+10分钟
            x = x.Format("HH:mm");
            if (startTime < x) {
                startTime = x;
            }
        }
        //冲突检测，若无冲突设置startTime //TODO 模块划分未优化
        hs.check_conflict(hs,startTime,l)

    },
    check_conflict: function (hs,startTime,l) {
        var cf = 0;
        var a1 = hs.getDivArr(hs);
        var allowReUse = 0;
        var content ="";
        var dur = hs.data.service_home.service_time
        var c = time_conflict(a1, startTime ,dur - allowReUse);
        if( startTime >= l.end) {
            content = "抱歉！您预约的项目服务时长"+dur+"分钟，该时间段剩余时间不足，请预约其他时间或技师！";
            cf = !0;
        }
        if (c[0]) {
            cf = !0
            var last = c[0];
            var s = 10;
            while ( c[0] < l.end  && cf && --s>0) {
                if (c[0]) {
                    var y  = new Date();
                    y.setHours(c[0].split(":")[0], c[0].split(":")[1], 0);
                    startTime = y.Format("HH:mm");
                }
                if (last == startTime && c[1] && c[1] < l.end) {
                    var y  = new Date();
                    y.setHours(c[1].split(":")[0], c[1].split(":")[1], 0);
                    startTime = y.Format("HH:mm");
                }
                if (last == startTime){
                    s = 0
                }else{
                    last = startTime;
                    c = time_conflict(a1, startTime, dur - allowReUse);
                }
                if(!c[0] && !c[1]) {cf = 0;}
            }
            if (c[0]  ) {
                if(c[0] > hs.data.time_list[hs.data.time_list.length-1].start) {
                    content = "抱歉！您预约的项目服务时长"+dur+"分钟,大于该时间段剩余时间，请您预约当天其他时间或预约次日！";
                }else{
                    content = "抱歉！您预约的项目服务时长"+dur+"分钟，与下一时间段顾客预约时间冲突，请预约其他时间或技师！";
                }

                cf = !0;
            }
        }
        if(cf){
            wx.showModal({
                title: "提示",
                content: content,
                showCancel: false,
                confirmText: "朕知道了"
            })
            hs.setData({startTime:""});
            return
        }
        hs.setData({startTime:startTime});
    },
    getDivArr:function(d) {
        //d = this
        //计算此段及下一段的时间片数组
        var td=d.data.time_list[d.data.time_curr]
        var a1 = (td.div) ? JSON.parse(td.div) :[];
        if (d.data.time_curr < (d.data.time_list.length - 1) && d.data.time_list[d.data.time_curr + 1]) {
            var td1 = d.data.time_list[d.data.time_curr + 1]
            if (td1.div) {
                if (!a1 || a1.length == 0) {
                    a1=JSON.parse(td1.div)
                }else{
                    var a2 = JSON.parse(td1.div)
                    for (var i in a1) {
                        for (var j in a2) {
                            if (a2[0].toString() != a1[0].toString()) { // typeof() = object
                                a1.push(a2[j]);
                            }
                        }
                    }
                }
            }
        }
        if (d.data.time_curr < (d.data.time_list.length - 2) && d.data.time_list[d.data.time_curr + 2]) {
            var td1 = d.data.time_list[d.data.time_curr + 2]
            if (td1.div) {
                if (!a1 || a1.length == 0) {
                    a1=JSON.parse(td1.div)
                }else{
                    var a2 = JSON.parse(td1.div)
                    for (var i in a1) {
                        for (var j in a2) {
                            if (a2[0].toString() != a1[0].toString()) { // typeof() = object
                                a1.push(a2[j]);
                            }
                        }
                    }
                }
            }
        }
        return a1
    },
    timeTunePlus: function() {
        var d = this;
        var x = new Date();
        x.setHours(d.data.startTime.split(':')[0],d.data.startTime.split(':')[1],0)
        var x0 = x.Format("HH:mm")
        var td=d.data.time_list[d.data.time_curr]
        x.setMinutes((Math.floor(x.getMinutes()/10)+ 1)*10,0,0);
        x = x.Format("HH:mm")
        if (x >= td.end) return;
        var a1 = d.getDivArr(d), s = 10, c
        while (--s>0 ){
            c = time_conflict(a1,x, d.data.service_home.service_time);
            //console.log(c[0],c[1],x)
            if( c[0] || c[1] ) {
                var x = new Date();
                x.setHours(c[0].split(':')[0],c[0].split(':')[1],0)
                x.setMinutes(x.getMinutes() - parseInt(d.data.service_home.service_time))
                var x2 = x.Format("HH:mm")
                if(x2 >= td.end ) {
                    s = 0;
                }else{
                    if( x2 > x0  ) {
                        x = x2;
                    } else {
                        x = c[1]
                    }
                }
            }else{
                x0 = x
                s = 0;
            }
        }
        if (td.start <= x0 && x0 < td.end ) {
            d.setData({startTime: x0})
            return x0
        }
        return 0
    },
    timeTuneMinus: function() {
        var d = this;
        var td = d.data.time_list[d.data.time_curr]
        var x = new Date;
        x.setHours(d.data.startTime.split(':')[0],d.data.startTime.split(':')[1],0)
        var x0 = x.Format("HH:mm")
        x.setMinutes((Math.ceil(x.getMinutes()/10) - 1)*10,0,0);
        x = x.Format("HH:mm");
        if( x < td.start) return;
        /* 若为当天，时间须晚于当前时间10分钟 */
        var t = new Date(nowYear+'/'+( d.data.date[d.data.date_curr].date) .replace('月','/').replace('日',''));//所选日期
        if (t.toDateString() === new Date().toDateString()) {  //今天
            var y = new Date();
            y.setMinutes(y.getMinutes() + 10, 0, 0);// +10分钟
            y = y.Format("HH:mm");
            //y = '22:59'; //:49 +10 onlyfortest
            if (x < y) {
                x = y;
            }
        }
        var a1 = d.getDivArr(d), s = 10, c, cf = true
        while (--s>0 ){
            c = time_conflict(a1, x, d.data.service_home.service_time);
            //console.log(c[0],c[1],x)
            if( c[0] || c[1] ) {
                if (c[1] && c[1] < x0){
                    x = c[1]
                    //s = 0
                }else{
                    if ( c[0] <= td.start ){
                        s = 0
                    } else {
                        var x = new Date();
                        x.setHours(c[0].split(':')[0],c[0].split(':')[1],0)
                        x.setMinutes(x.getMinutes() - parseInt(d.data.service_home.service_time))
                        x = x.Format("HH:mm")
                        if ( x < td.start){
                            s = 0
                        }
                    }
                }
            }else{
                x0 = x
                s = 0;
                cf = 0;
            }
        }

        if (td.start <= x0 && x0 < td.end && !cf ) {
            d.setData({startTime: x0})
            return x0;
        }
        return 0;

    },

    member_on: function() {
        //选择技师接口
        var a = this;
        if ("" != a.data.id && null != a.data.id) {
            if (1 != a.data.service_type) {
                a.setData({
                    member_page: !0
                });
                var t = {
                    op: "store_member",
                    pid: a.data.service_id,
                    id: a.data.id,
                    page: a.data.page,
                    pagesize: a.data.pagesize
                };
                "" != a.data.service_id && null != a.data.service_id && (t.service = a.data.service_id), 
                app.util.request({
                    url: "entry/wxapp/index",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data ? a.setData({
                            member_list: e.data,
                            page: a.data.page
                        }) : a.setData({
                            isbottom: !0
                        });
                    }
                });
            }
        } else wx.showModal({
            title: "提示",
            showCancel:false,
            content: "请先选择门店",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    member_close: function() {
        this.setData({
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        });
    },
    member_choose: function(t) {
        var d = this, e = t.currentTarget.dataset.index, a = d.data.member_list;
        this.setData({
            member_id: a[e].id,
            member_name: a[e].name,
            member_page: !1,
            page: 1,
            startTime:"",
            isbottom: !1,
            member_list: []
        })
        if ( undefined!=d.data.multiOrder && undefined !=d.data.date_curr &&  0 == d.data.multi_curr[d.data.date_curr]
            && -1!=d.data.multiOrder.indexOf(d.data.date_curr)){
            d.protect_time_choose(d)
            return
        }
        get_time(d);
        if ( undefined!=d.data.multiOrder && undefined !=d.data.date_curr &&  1 == d.data.multi_curr[d.data.date_curr]
            && -1!=d.data.multiOrder.indexOf(d.data.date_curr)){
            d.protect_time_choose1(d)
            return
        }
    },
    service_on: function() {
        var a = this;
        if(a.data.sid != -1) return
        if ("" != a.data.id && null != a.data.id) {
            a.setData({
                shadow: !0,
                service_page: !0
            });
            var t = {
                op: "store_service",
                id: a.data.id
            };
            "" != a.data.member_id && null != a.data.member_id && (t.member = a.data.member_id), 
            -1 != a.data.service_type && (t.service_type = a.data.service_type), app.util.request({
                url: "entry/wxapp/index",
                data: t,
                success: function(t) {
                    var e = t.data;
                    "" != e.data && a.setData({
                        service_list: e.data
                    });
                }
            });
        } else wx.showModal({
            title: "提示",
            showCancel:false,
            content: "请先选择门店",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    service_close: function() {
        this.setData({
            shadow: !1,
            service_page: !1,
            service_list: []
        });
    },
    service_choose: function(t) {
        var d = this, e = t.currentTarget.dataset.index, a = this.data.service_list;
        var sc = parseFloat(this.data.card.content.discount) / 10
        var o_amount = (sc < 10) ? (parseFloat(a[e].price) * sc).toFixed(2) : a[e].price;
        d.setData({
            shadow: !1,
            service_page: !1,
            service_id: a[e].id,
            service_name: a[e].name,
            service_home: a[e],
            service_list: [],
            o_amount:o_amount
        });
        d.auto_coupon_choose();

        ( undefined!=d.data.multiOrder && undefined !=d.data.date_curr && -1!=d.data.multiOrder.indexOf(d.data.date_curr))
        && undefined == d.data.multi_curr[d.data.date_curr]  && d.setData({multi_page:1});
        d.data.startTime && (d.check_conflict(d, d.data.startTime, d.data.time_list[d.data.time_curr]));
    },
    reset: function(t) {
        var e = t.currentTarget.dataset.index;
        1 == e ? (this.setData({
            member_id: null,
            member_name: null
        }), get_time(this)) : 2 == e && this.setData({
            service_id: null,
            service_name: null,
            o_amount:""
        });
    },
    menu_on: function() {
        this.setData({
            menu: !0,
            shadow2: !0
        });
    },
    menu_close: function() {
        this.setData({
            menu: !1,
            shadow2: !1,
            pay: !1
        });
    },
    pay_choose: function(a) {
        var t = a.currentTarget.dataset.index;
        t != this.data.pay_type && this.setData({
            pay_type: t
        });
    },
    auto_coupon_choose:function(a){
        var d = this,t;
        if ( !(t=d.data.coupon)) {
            d.calc_amt(d)
            return
        }
        var coupon_curr = -1
        var coupon_price = 0;
        //Object.getOwnPropertyNames(t.data).forEach(function(key){//Reflect.ownKeys(t).forEach(function(i){ if (i<t.length)
        for (var i in t){
            if ( t[i].coupon.name - coupon_price > 0) {
                coupon_curr = i;
                coupon_price = t[i].coupon.name;
            }
        }
        "" != t && d.setData({
            coupon: t, coupon_curr: coupon_curr, coupon_price: coupon_price,
            o_amount:(d.data.o_amount - coupon_price),
            coupon_uid:t[coupon_curr]['id']
        });
        d.calc_amt(d)
    },
    coupon_choose: function(a) {
        var d = this, o = a.currentTarget.dataset.index,  n = d.data.service_home.amount, c;
        //(3 == d.data.service_type) && (n = d.data.service_home.group_price);
        //(3 != d.data.service_type && d.data.flash) && (n = d.data.service_home.flash_price);
        //(3 != d.data.service_type && !d.data.flash) && (n = d.data.service_home.price);
        //
        //console.log('o:'+o)
        if (o != d.data.coupon_curr) {
            var e = d.data.coupon[o].coupon.name
            //"" != (c = d.data.card) && null != c && 1 == d.data.userinfo.card && 1 == c.content.discount_status && (n = (parseFloat(n) * parseFloat(c.content.discount) / 10).toFixed(2)),
            //    n = (parseFloat(n) - parseFloat(e)).toFixed(2),
            d.setData({
                coupon_curr: o,
                coupon_uid: d.data.coupon[o]['id'],
                coupon_price: e,
                //o_amount: n
            });
        } else {
            //"" != (c = d.data.card) && null != c && 1 == d.data.userinfo.card && 1 == c.content.discount_status && (n = (parseFloat(n) * parseFloat(c.content.discount) / 10).toFixed(2)),
            d.setData({
                coupon_curr: -1,
                coupon_uid:-1,
                coupon_price: null,
                //o_amount: n
            });
        }
        d.calc_amt(d)
    },
    calc_amt:function(d){
        var n, c, x, r, a= d.data, h = a.service_home;
        (a.group) && (h.group_price);
        (!a.group && a.flash && h.flash_price) && (n = parseFloat(h.flash_price));
        (!a.group && !a.flash && h.price) && (n = parseFloat(h.price));
        "" != (c = a.card) && null != c && 1 == a.userinfo.card && 1 == c.content.discount_status
        && (n = (parseFloat(n) * parseFloat(c.content.discount) / 10).toFixed(2));
        var dc= a.date_curr, dt= a.times, w= a.date[dc].week - 1;//1210
        r = ( dt[w].discount_rate ) ? dt[w].discount_rate : -1;
        -1 != dc && -1!= r && 1!= a.group && 1 == h.d_week_status && (n = n * r / 10);
        a.coupon && -1 != a.coupon_curr && (x = a.coupon[a.coupon_curr].coupon.name) && (n = (parseFloat(n) - parseFloat( x )).toFixed(2));
        d.setData({ o_amount: n ,d_week_rate: r });
    },
    submit: function(ex) {
        var o = this;
        if (sign(o), o.data.submit) {
            var sd = {
                id: o.data.service_id,
                total: 1,
                name: o.data.name,
                mobile: o.data.mobile,
                store: o.data.id,
                member: o.data.member_id,
                service_type: o.data.service_type,
                order_type: o.data.order_type,
                clone: 1,
                openid: o.data.userinfo.openid,
                //emp_mo: 0,
                startDate: o.data.startDate,
                startTime: o.data.startTime,
                startWeek: o.data.date[o.data.date_curr].week,
                multiOrder: o.data.multi_curr[o.data.date_curr],
                d_week_rate: o.data.d_week_rate,
                form_id: ex.detail.form_id

            };
            "" != o.data.address && null != o.data.address && "undefined" != o.data.address && (sd.address = o.data.address),
            "" != o.data.map && null != o.data.map && "undefined" != o.data.map && (sd.map = JSON.stringify(o.data.map)),
            null != o.data.kind && null != o.data.kind && (sd.kind = o.data.kind), "" != o.data.group && null != o.data.group && (sd.group = o.data.group),
            "" != o.data.group_id && null != o.data.group_id && (sd.group_id = o.data.group_id),
            "" != o.data.flash && null != o.data.flash && (sd.flash = o.data.flash),
            (1 == o.data.time_status && (null == o.data.group || "" == o.data.group || 1== o.data.group) || 1 == o.data.group_time && null != o.data.group && "" != o.data.group) && (sd.plan_date = o.data.date[o.data.date_curr].date + " " + o.data.time_list[o.data.time_curr].start + "-" + o.data.time_list[o.data.time_curr].end,
                sd.date = o.data.date[o.data.date_curr].date, null != o.data.time_list[o.data.time_curr].shop_member && "" != o.data.time_list[o.data.time_curr].shop_member && (sd.shop_member = o.data.time_list[o.data.time_curr].shop_member),
            null != o.data.time_list[o.data.time_curr].home_member && "" != o.data.time_list[o.data.time_curr].home_member && (sd.home_member = o.data.time_list[o.data.time_curr].home_member))


        }else{
            return
        }
        if ( 2 == o.data.pay_type && o.data.userinfo.money - o.data.o_amount < 0) {
            wx.showModal({
                title: '提示',showCancel:0,
                showCancel:false,
                content: '您的余额不足，请选择其他支付方式或联系商家充值！',
                success: function (res) {
                }
            });
            return
        }
        if (1 == o.data.pay_type) { //1微信支付
            var t = {
                //out_trade_no: o.data.service_home.out_trade_no,
                coupon_uid: o.data.coupon_uid,
                pay_type: o.data.pay_type,
                form_id: ex.detail.formId
            };
            t = extend(t,sd);
            undefined != o.data.coupon_curr &&  -1 != o.data.coupon_curr && (t.coupon_id = o.data.coupon[o.data.coupon_curr].cid),
            "" != o.data.content && null != o.data.content && (t.content = o.data.content),
                app.util.request({
                    //url: "entry/wxapp/orderpay",
                    url: "entry/wxapp/setorder2",
                    data: t,
                    success: function(a) {
                        var t = a.data;
                        "" != t.data && (1 == t.data.status ? (console.log(t.data), wxpay(t.data, o)) : 2 == t.data.status && wx.redirectTo({
                            url: "../../pages/porder/success"
                        }));
                    }
                });
        } else if( 2 == o.data.pay_type) //2余额支付
        {
            var t = {
                //pay: !1,
                coupon_uid: o.data.coupon_uid,
                //sign: !0,
                //shadow: !0,
                form_id: ex.detail.formId
            }
            t = extend(t,sd);
            //o.setData(t);
            app.util.request({
                //url: "entry/wxapp/orderpay",
                url: "entry/wxapp/setorder2",
                data: t,
                success: function(a) {
                    var t = a.data.data;
                    //console.log('card pay..')
                    "" != t && (o.setData({
                        shadow: !1,
                        sign: !1,
                        password: ""
                    }), 1 == t.status ? wxpay(t.data, o) : 2 == t.status && (wx.showToast({
                        title: "支付成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        //console.log('sign_btn:'+o.data.list.order_type)
                        var redirUrl = null
                        var urlPayed = (null != o.group_id && undefined != o.group_id ) ?
                        "../../pages/group/detail?&id="+o.group_id
                            :"../../pages/order/order";
                        switch ( o.data.list.order_type ) {
                            case "3":
                                redirUrl =  "../../pages/group/detail?&id=" + t.group_id
                                break;
                            case "4":
                                redirUrl = "../../pages/order/order"
                                break;
                            default:
                                redirUrl = "../order/detail?&out_trade_no=" + o.data.list.out_trade_no
                        }
                        wx.navigateTo({url:urlPayed})
                        //wx.redirectTo({url:redirUrl})
                    }, 2e3)));
                }
            });
        }else if( 5==o.data.pay_type) // 5到店付
        {
            var t = {
                //out_trade_no: o.data.service_home.out_trade_no,
                coupon_uid: o.data.coupon_uid,
                pay_type: o.data.pay_type,
                form_id: ex.detail.formId
            };
            t = extend(t,sd);
            undefined != o.data.coupon_curr &&  -1 != o.data.coupon_curr && (t.coupon_id = o.data.coupon[o.data.coupon_curr].cid),
            "" != o.data.content && null != o.data.content && (t.content = o.data.content),
            app.util.request({
                //url: "entry/wxapp/orderpay",
                url: "entry/wxapp/setorder2",
                data: t,
                success: function (a) {
                    var d=a.data.data;
                    var urlPayed = ( undefined!=d && undefined != d.group_id && null != d.group_id ) ?
                    "../../pages/group/detail?&id="+d.group_id
                        :"../../pages/order/order";
                    //var urlPayed1 = "../../pages/porder/success";
                    //var urlPayed1 = "../order/detail?&out_trade_no=" + d.tid;
                    wx.showModal({
                        title: '提示',
                        showCancel:false,
                        content: '订单提交成功，需到店付款后才能使用!',
                        success: function (res) {
                            wx.navigateTo({url:urlPayed})
                        }
                    });
                }
            });
        }
    },
    input: function(a) {
        switch (a.currentTarget.dataset.name) {
            case "content":
                this.setData({
                    content: a.detail.value
                });
                break;

            case "password":
                this.setData({
                    password: a.detail.value
                });
        }
    },
    pwinput_close: function() {
        this.setData({
            shadow: !1,
            sign: !1,
            password: ""
        });
    },
    pwinput_btn: function() {
        var o = this, a = o.data.password;
        if ("" == a || null == a) o.setData({
            sign_error: !0
        }); else {
            var t = {
                id: o.data.service_id,
                total: 1,
                name: o.data.name,
                mobile: o.data.mobile,
                store: o.data.id,
                member: o.data.member_id,
                service_type: o.data.service_type,
                order_type: o.data.order_type,
                clone: 1,
                out_trade_no: o.data.list.out_trade_no,
                coupon_uid: o.data.coupon_uid,
                pay_type: o.data.pay_type,
                form_id: o.data.form_id,
                password: a
            };
            -1 != o.data.coupon_curr && (t.coupon_id = o.data.coupon[o.data.coupon_curr].cid),
            "" != o.data.content && null != o.data.content && (t.content = o.data.content),
            app.util.request({
                //url: "entry/wxapp/orderpay",
                url: "entry/wxapp/setorder2",
                data: t,
                success: function(a) {
                    var t = a.data.data;
                    "" != t && (o.setData({
                        shadow: !1,
                        sign: !1,
                        password: ""
                    }), 1 == t.status ? wxpay(t.data, o) : 2 == t.status && (wx.showToast({
                        title: "支付成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        var redirUrl = null
                        var urlPayed = (null != o.group_id && undefined != o.group_id ) ?
                        "../../pages/group/detail?&id="+o.group_id
                            :"../../pages/order/order";
                        switch ( o.data.list.order_type ) {
                            case "3":
                                redirUrl =  "../../pages/group/detail?&id=" + t.group_id
                                break;
                            case "4":
                                redirUrl = "../../pages/order/order"
                                break;
                            default:
                                redirUrl = "../order/detail?&out_trade_no=" + o.data.list.out_trade_no
                        }
                        wx.navigateTo({url:urlPayed})
                        //wx.redirectTo({url:redirUrl})
                    }, 2e3)));
                }
            });
        }
    },

    onLoad: function(r) {
        var d = this;
        var order_type = (undefined == r.ot) ? 4 : r.ot
        var sid  = (undefined == r.sid) ? -1 : r.sid
        var ch_sid = (undefined == r.sid) ? 1 : 0
        //undefined != r.sid &&
        d.setData({sid: sid , order_type :order_type, ch_sid:ch_sid})
        "" != r.kind && null != r.kind && d.setData({
            kind: r.kind
        }), "" != r.group && null != r.group && d.setData({
            group: r.group
        }), "" != r.group_id && null != r.group_id && d.setData({
            group_id: r.group_id
        }), "" != r.flash && null != r.flash && d.setData({
            flash: r.flash
        });
        common.config(d),common.theme(d);

        if ("" == d.data.config) {
            //common.login(n),
            app.util.request({
                url: "entry/wxapp/index",
                data: {
                    op: "base"
                },
                showLoading: !1,
                success: function (e) {
                    var r = e.data, n = 1;
                    var baseurl = e.data.data.theme.content.homepage;
                    "" != r.data && ("" != r.data.config && null != r.data.config && (app.config = r.data.config) && (i.setData({config: r.data.config.content})),
                    "" != r.data.theme && null != r.data.theme && (app.theme = r.data.theme, "" != r.data.theme.content && null != r.data.theme.content && 3 == r.data.theme.content.theme && (n = 3)),
                    "" != r.data.map && null != r.data.map && (app.map = r.data.map), "" != r.data.share && null != r.data.share && (app.share = r.data.share));
                    //
                    var n = d.data.config, o = 1, m = 1;
                    "" != n && null != n && ("" != n.home_status && null != n.home_status && (o = n.home_status),
                    "" != n.online_time && null != n.online_time && (m = n.online_time)), d.setData({
                        home_status: o,
                        online_time: m
                    }),
                    -1 == o && d.setData({ service_type: 2 });
                    d.setData({service_type:2});//todo check....
                }
            })
        }

        for (var t = [], e = 0; e < 5; e++) {
            (s = {}).index = e, s.date = GetDateStr(e), s.week = getMyDay(e), s.name = 0 == e ? "今天" : getMyDay2(e),
            t.push(s);
        }

        if (d.setData({date: t,startDate:t[0].date}), "" != r.id && null != r.id) d.setData({id: r.id});
        else {
            var mp = ( app.map )? app.map :""
            // todo map一直是空
            var t = -1;
            null != mp && "" != mp && "" != mp.content && null != mp.content && 1 == mp.content.store && (t = ""),
            d.setData({ id: t, map: mp });
        }

        var s = {op: "store_order" };
        "" != d.data.id && null != d.data.id && -1 != d.data.id && (s.id = d.data.id)
        "" != d.data.sid && -1 != d.data.sid  && (s.sid = d.data.sid)
        app.util.request({
            url: "entry/wxapp/service",
            data:s,
            success: function(t) {
                var e = t.data;
              console.log(e)///////////
               // 存储openid
              wx.setStorageSync('openid', e.data.userinfo.openid)
              var openid = wx.getStorageSync('openid')
              console.log("~~~~~~~", openid)
              // /////////////////////////
                "" != e.data && ("" != e.data.list && null != e.data.list && d.setData({
                    list: e.data.list,
                    id: e.data.list.id
                }), "" != r.member_id && null != r.member_id && "" != r.member_name && null != r.member_name && d.setData({
                    member_id: r.member_id,
                    member_name: r.member_name
                }), "" != e.data.times && null != e.data.times && (d.setData({
                    times: e.data.times
                }), get_time(d)), d.data.service_home && d.calc_amt(d), d.setData({
                    more_store: e.data.more_store
                }));
                null!= e.data.service && d.setData({service_id: e.data.service.id,service_name: e.data.service.name,
                    service_home: e.data.service, o_amount: e.data.service.price})
                null != e.data.coupon && d.setData({coupon: e.data.coupon})
                null != e.data.card && d.setData({card:  e.data.card})
                null != e.data.userinfo && d.setData({userinfo:  e.data.userinfo})
                null != e.data.multiOrder && d.setData({multiOrder:  e.data.multiOrder})
                null != e.data.multiStartTime && d.setData({multiStartTime:  e.data.multiStartTime})
                if( undefined!=d.data.sid && 0<d.data.sid ){/*从项目列表购买*/
                    (undefined!=d.data.multiOrder && undefined !=d.data.date_curr && -1!=d.data.multiOrder.indexOf(d.data.date_curr)) &&
                        d.setData({multi_page:1});
                    d.auto_coupon_choose() /*自动选择优惠券和金额*/
                }
            }
        });
        var n = d.data.config, o = -1, m = -1;
        "" != n && null != n && ("" != n.home_status && null != n.home_status && (o = n.home_status), 
        "" != n.online_time && null != n.online_time && (m = n.online_time)), d.setData({
            home_status: o,
            online_time: m
        }),
        -1 == o && d.setData({ service_type: 2 });
        d.setData({service_type:2});
    },
    onReady: function() {},
    onShow: function() {
        var d = this;
        app.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "address_default"
            },
            success: function(t) {
                var e = t.data;
                if ("" != e.data) {
                    e.data.address;
                    "" != e.data.content && null != e.data.content && e.data.content, d.setData({
                        name: e.data.name,
                        mobile: e.data.mobile,
                        address: e.data.address,
                        content: e.data.content,
                    });
                }
                if (d.data.member_id){
                    get_time(d)
                }
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var d = this;
        !d.data.isbottom && d.data.member_page && app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "store_member",
                id: d.data.id,
                page: d.data.page,
                pagesize: d.data.pagesize
            },
            success: function(t) {
                var e = t.data;
                "" != e.data ? d.setData({
                    member_list: d.data.member_list.concat(e.data),
                    page: d.data.page
                }) : d.setData({
                    isbottom: !0
                });
            }
        });
    }
});
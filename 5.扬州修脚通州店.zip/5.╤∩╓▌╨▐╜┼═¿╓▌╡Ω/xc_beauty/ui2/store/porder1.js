var app = getApp(), common = require("../common/common.js");
var now = new Date(); //当前日期
var nowDayOfWeek = now.getDay(); //今天本周的第几天
var nowDay = now.getDate(); //当前日
var nowMonth = now.getMonth(); //当前月
var nowYear = now.getYear(); //当前年
nowYear += (nowYear < 2000) ? 1900 : 0; //有2100问题
var currentHours = now.getHours();//当前小时
var currentMinute = now.getMinutes();//当前分钟`

var lastMonthDate = new Date(); //上月日期
lastMonthDate.setDate(1);
lastMonthDate.setMonth(lastMonthDate.getMonth()-1);
var lastYear = lastMonthDate.getYear();
var lastMonth = lastMonthDate.getMonth();


// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "H+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

function GetDateStr(t) {
    var e = new Date();
    e.setDate(e.getDate() + t);
    e.getFullYear();
    return e.getMonth() + 1 + "月" + e.getDate() + "日";
}

function getMyDay(t) {
    var e = new Date();
    return e.setDate(e.getDate() + t), 0 == e.getDay() && "周日", 1 == e.getDay() && "周一", 
    2 == e.getDay() && "周二", 3 == e.getDay() && "周三", 4 == e.getDay() && "周四", 5 == e.getDay() && "周五", 
    6 == e.getDay() && "周六", e.getDay();
}

function getMyDay2(t) {
    var e, a = new Date();
    return a.setDate(a.getDate() + t), 0 == a.getDay() && (e = "周日"), 1 == a.getDay() && (e = "周一"), 
    2 == a.getDay() && (e = "周二"), 3 == a.getDay() && (e = "周三"), 4 == a.getDay() && (e = "周四"), 
    5 == a.getDay() && (e = "周五"), 6 == a.getDay() && (e = "周六"), e;
}

function get_time(i) {
    var d = i.data.times, r = [], s = !1;
    i.setData({
        time_list: s,
        tip: s
    }), 1 == i.data.online_time && app.util.request({
        url: "entry/wxapp/user",
        showLoading: !1,
        data: {
            op: "plan_date",
            plan_date: i.data.date[i.data.date_curr].date,
            id: i.data.id
        },
        success: function(t) {
            var e = t.data;
            if ("" != e.data) {
                if (1 == e.data.status) for (var a = 0; a < d.length; a++) d[a].week == i.data.date[i.data.date_curr].week ? r = d[a].content : 7 == d[a].week && 0 == i.data.date[i.data.date_curr].week && (r = d[a].content); else s = !0;
                "" != i.data.member_id && null != i.data.member_id ? app.util.request({
                    url: "entry/wxapp/user",
                    data: {
                        op: "times_log",
                        member: i.data.member_id,
                        plan_date: i.data.date[i.data.date_curr].date,
                        list: JSON.stringify(r),
                        index: i.data.date[i.data.date_curr].index
                    },
                    success: function(t) {
                        var e = t.data;
                        "" != e.data ? i.setData({
                            tip: s,
                            time_curr: -1,
                            time_list: e.data
                        }) : i.setData({
                            tip: s,
                            time_curr: -1,
                            time_list: r
                        });
                    }
                }) : i.setData({
                    time_curr: -1,
                    time_list: r,
                    tip: s
                });
            }
        }
    });
}

function sign(t) {
    var e = t.data.time_curr, a = t.data.name, i = (t.data.mobile, t.data.member_id), d = t.data.service_id, r = t.data.service_type, s = "";
    //1 == t.data.online_time && -1 == e && (s = "请选择时间"),
    "" != a && null != a || (s = "请填写预约人信息"),
    "" != i && null != i || (s = "请选择服务人员"),
    "" != d && null != d || (s = "请选择服务项目"),
    //-1 == r && (s = "请选择服务方式"),
        "" == s ? t.setData({
        submit: !0
    }) : wx.showModal({
        title: "提示",
        showCancel:false,
        content: s
    });
}

Page({
    data: {
        pagePath: "../store/porder1",
        date_curr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        submit: !1,
        time_curr: -1,
        service_type: -1,
        pickTimeStart:"08:00",
        pickTimeEnd:"23:59",
        dateFrom:""
    },
    tab: function(t) {
        var e = this, a = (e.data.service_home, t.currentTarget.dataset.index);
        if (undefined != e.data.service_home) {
            var g = e.data.service_home.home;
            if (-1 == g && 1 == a) {
                wx.showModal({
                    title: "提示",
                    showCancel:false,
                    content: "团购暂不支持上门服务"
                });
                return;
            }
        }
        a != e.data.service_type && (1 == a ? e.setData({
            member_id: -2,
            member_name: "店内安排"
        }) : e.setData({
            member_id: null,
            member_name: null
        }), e.setData({
            service_type: a
        }), get_time(e));
    },
    qie: function() {
        var i = this;
        1 == i.data.more_store && -1 != i.data.id && (i.setData({
            store_page: !0,
            store_list: []
        }), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var e = t.latitude, a = t.longitude;
                t.speed, t.accuracy;
                i.setData({
                    latitude: e,
                    longitude: a
                });
            },
            complete: function() {
                var t = {
                    op: "store",
                    page: i.data.page,
                    pagesize: i.data.pagesize
                };
                null != i.data.latitude && "" != i.data.latitude && (t.latitude = i.data.latitude), 
                null != i.data.longitude && "" != i.data.longitude && (t.longitude = i.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/order",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data && (i.setData({
                            store_list: e.data
                        }), get_time(i));
                    }
                });
            }
        }));
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        e.setData({
            list: e.data.store_list[a],
            id: e.data.store_list[a].id,
            store_page: !1
        }), 1 != e.data.service_type && e.setData({
            member_id: ""
        }), get_time(e);
    },
    calc_amt:function(d){
        var n,c,x, r,o = d.data.order, a= d.data, h = a.service_home;
        h && ( n = parseFloat( h.price ));
        if (o && 0 == a.clone && a.service_id == o.pid) {
            (o.group) && (n = o.group_price);
            (!o.group && -1 != o.flash) && (n = o.flash_price);
            (!o.group && -1 == o.flash) && (n = parseFloat(o.price));
        }
        var dc= d.data.date_curr, dt= d.data.times, w= d.data.date[dc].week - 1;//1210
        r = dt[w].discount_rate ? dt[w].discount_rate : -1;
        null!= dc && -1 != dc && 1==h.d_week_status && r != -1  && (n = n * r / 10);
        "" != (c = d.data.card) && null != c && 1 == d.data.userinfo.card && 1 == c.content.discount_status
        && (n = (parseFloat(n) * parseFloat(c.content.discount) / 10).toFixed(2));
        if(0 == d.data.clone && o.o_amount ) {
            n = n - parseFloat(o.amount) + parseFloat(o.o_amount);
        }
        d.setData({ o_amount: n, d_week_rate: r  });
    },
    call: function(t) {
        var e = this;
        null != e.data.id && "" != e.data.id && (-1 == e.data.id ? wx.makePhoneCall({
            phoneNumber: e.data.map.content.mobile
        }) : wx.makePhoneCall({
            phoneNumber: e.data.list.mobile
        }));
    },
    map: function(t) {
        var e = this;
        null != e.data.id && "" != e.data.id && (-1 == e.data.id ? wx.openLocation({
            latitude: parseFloat(e.data.map.content.latitude),
            longitude: parseFloat(e.data.map.content.longitude),
            name: e.data.map.content.address,
            address: e.data.map.content.address,
            scale: 28
        }) : wx.openLocation({
            latitude: parseFloat(e.data.list.map.latitude),
            longitude: parseFloat(e.data.list.map.longitude),
            name: e.data.list.address,
            address: e.data.list.address,
            scale: 28
        }));
    },
    bindTime1Change: function(t) {
        var d = this, endTime="",now,st=30;
        d.data.service_time && (st = parseInt(d.data.service_time));
        if (undefined != st ){
            now = new Date(nowYear+'/'+ d.data.startDate.replace('月','/').replace('日','')+' '+ t.detail.value);
            endTime = now.setMinutes(now.getMinutes()+st,0);
            endTime = new Date(endTime).Format("MM月dd日 HH:mm");
        }
        d.setData({
            startTime:t.detail.value,
            end_time:endTime
        })
    },
    date_choose: function(t) {
        var d = this, a = t.currentTarget.dataset.index, endTime="";
        if (a != d.data.date_curr){
            var startDate=d.data.date[a]['date']
            var now = new Date(nowYear+'/'+startDate.replace('月','/').replace('日','')+' '+d.data.startTime);
            if (undefined != d.data.service_time ) {
                endTime = now.setMinutes(now.getMinutes() + parseInt(d.data.service_time));
                endTime = new Date(endTime).Format("MM月dd日 HH:mm");
            }
            d.setData({
                date_curr: a,
                time_curr: -1,
                startDate: d.data.date[a]['date'],
                end_time:endTime
            })
            //get_time(d)
            d.data.service_id && d.calc_amt(d);
        };
    },
    date_left: function() {
        var d = this;
        if (0 < d.data.date_curr) d.setData({
            date_curr: d.data.date_curr - 1,
            time_curr: -1
        }), get_time(d); else {
            var e = d.data.date;
            if (0 < e[d.data.date_curr].index) {
                var a = {};
                a.index = e[d.data.date_curr].index - 1, a.date = GetDateStr(a.index), a.week = getMyDay(a.index),
                0 == a.index ? a.name = "今天" : a.name = getMyDay2(a.index), e.splice(e.length - 1, 1), 
                e.unshift(a), d.setData({
                    date: e,
                    time_curr: -1
                }), get_time(d);
            }
        }
    },
    date_right: function() {
        var t = this;
        if (t.data.date_curr < t.data.date.length - 1) t.setData({
            date_curr: t.data.date_curr + 1,
            time_curr: -1
        }), get_time(t); else {
            var e = t.data.date, a = {};
            a.index = e[t.data.date_curr].index + 1, a.date = GetDateStr(a.index), a.week = getMyDay(a.index), 
            0 == a.index ? a.name = "今天" : a.name = getMyDay2(a.index), e.splice(0, 1), e.push(a), 
            t.setData({
                date: e,
                time_curr: -1
            }), get_time(t);
        }
    },
    time_choose: function(t) {
        var a = t.currentTarget.dataset.index;
        var d = this.data.time_list[a];
        if ( undefined == this.data.service_name || "" == this.data.service_name ) {
            wx.showModal({
                //title: "提示",
                content:"请先选择【服务项目】",
                showCancel:false,
                confirmText:"朕知道了"
            })
            return;
        }
        if ( undefined == this.data.member_name || "" == this.data.member_name) {
            wx.showModal({
                //title: "提示",
                content:"请先选择【服务人员】",
                showCancel:false,
                confirmText:"朕知道了"
            })
            return;
        }
        a != this.data.time_curr && this.setData({
            time_curr: a
        });

        //上门服务不需要预约时长估算 2018-09-25
        if (1 == this.data.service_type) return;

        var content = "";
        if ( d.total > 0 ) {
            content = "该时间段，前面已有"+ d.total+"人预约";
        }
        if (d.service_time > 0){
            var hour =  Math.floor(d.service_time / 60);
            var time1content = (hour>0)?hour+"小时":"";
            var minute = d.service_time % 60;
            time1content = time1content + ( minute>0 ? minute + "分钟":"");
            var tempStrs = d.start.split(":");  //截取时间
            var minute1 =  tempStrs[1] + minute  ;
            var hour1 = tempStrs[0] * 1 +  hour + Math.floor( minute1 / 60 ) ;
            minute1 = minute1 % 60;
            if (minute1 < 10) {
                minute1 = "0" + minute1;
            }
            content = content + "，预计服务时长"+ time1content +"，请于" + hour1+":"+ minute1 +"左右到店。若时间不便，请预约其他时间或技师";
        }else{
            content = "恭喜您！该时间段，前面无人预约，请于"+ d.start.replace(/\b(09)/gi,"9")+"进店接受服务！"
        }

        if( "" != content ) {
            wx.showModal({
                title: "提示",
                content:content,
                showCancel:false,
                confirmText:"朕知道了"
            })
        }
    },

    member_on: function() {
        //选择技师接口
        var a = this;
        if ("" != a.data.id && null != a.data.id) {
            if (1 != a.data.service_type) {
                a.setData({
                    member_page: !0
                });
                var t = {
                    op: "store_member",
                    pid: a.data.service_id,
                    id: a.data.id,
                    page: a.data.page,
                    pagesize: a.data.pagesize
                };
                "" != a.data.service_id && null != a.data.service_id && (t.service = a.data.service_id), 
                app.util.request({
                    url: "entry/wxapp/index",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data ? a.setData({
                            member_list: e.data,
                            page: a.data.page
                        }) : a.setData({
                            isbottom: !0
                        });
                    }
                });
            }
        } else wx.showModal({
            title: "提示",
            showCancel:false,
            content: "请先选择门店",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    member_close: function() {
        this.setData({
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        });
    },
    member_choose: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.member_list;
        this.setData({
            member_id: a[e].id,
            member_name: a[e].name,
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        }), get_time(this);
    },
    service_on: function() {
        var a = this;
        if ("" != a.data.id && null != a.data.id) {
            a.setData({
                shadow: !1,
                service_page: !0
            });
            var t = {
                op: "store_service",
                id: a.data.id,
                emp:1
            };
            "" != a.data.member_id && null != a.data.member_id && (t.member = a.data.member_id), 
            -1 != a.data.service_type && (t.service_type = a.data.service_type), app.util.request({
                url: "entry/wxapp/index",
                data: t,
                success: function(t) {
                    var e = t.data;
                    "" != e.data && a.setData({
                        service_list: e.data
                    });
                }
            });
        } else wx.showModal({
            title: "提示",
            showCancel:false,
            content: "请先选择门店",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    service_close: function() {
        this.setData({
            shadow: !0,
            service_page: !1,
            service_list: []
        });
    },
    service_choose: function(t) {
        var d=this,e=t.currentTarget.dataset.index, a=d.data.service_list, st=30, endTime="",
            now=new Date(nowYear+'/'+d.data.startDate.replace('月','/').replace('日','')+' '+d.data.startTime)
            t = a[e].service_time;
            t && ""!=t && (st = parseInt(t));
            endTime = now.setMinutes(now.getMinutes()+ st),
            endTime = new Date(endTime).Format("MM月dd日 HH:mm");
        d.setData({
            shadow: !0,
            service_page: !1,
            service_id: a[e].id,
            service_name: a[e].name,
            service_time: st,
            service_home: a[e],
            end_time:endTime,
            service_list: []
        });
        d.data.service_id && d.calc_amt(d);
    },
    clear_all:function(){
        this.setData({
            service_id:null,
            service_name: null,
            member_id: null,
            member_name: null
        });
    },
    input1: function(a) {
        this.setData({
            name: a.detail.value
        });
    },
    clearinput1:function(){
        var a=this
        a.setData({name:""})
    },
    input2: function(a) {
        this.setData({
            mobile: a.detail.value
        });
    },
    clearinput2:function(){
        var a=this
        a.setData({mobile:""})
    },
    reset: function(t) {
        var e = t.currentTarget.dataset.index;
        1 == e ? (this.setData({
            member_id: null,
            member_name: null
        }), get_time(this)) : 2 == e && this.setData({
            service_id: null,
            service_name: null
        });
    },
    submit: function(sm) {
        var d = this;
        var form_id = sm.detail.formId, userinfo, oid, store, openid, out_trade_no;
        //d.data.service_type = d.data.service_type === -1 ? 2 : d.data.service_type
        if (d.data.clone == 2) {
            userinfo = { name: d.data.name, mobile: d.data.mobile };
            userinfo = JSON.stringify(userinfo);
            store = d.data.id;
            oid = -1;
            openid = -1;
            out_trade_no = -1;
        }else{
            userinfo = JSON.stringify(d.data.order.userinfo);
            store = d.data.order.store;
            oid = d.data.order.id;
            openid = d.data.order.openid;
            out_trade_no = d.data.order.out_trade_no;
        }
        if (sign(d), d.data.submit) {
            var e = {
                id: d.data.service_id,
                oid: oid,
                total: 1,
                name: d.data.name,
                mobile: d.data.mobile,
                store: store,
                member: d.data.member_id,
                service_type: d.data.service_type,
                order_type: 4,
                d_week_rate: d.data.d_week_rate,
                openid: openid,
                out_trace_no: out_trade_no,
                emp_mo: 1,
                clone: d.data.clone,
                userinfo: userinfo,
                startDate: d.data.startDate,
                startTime: d.data.startTime,
                startWeek: d.data.date[d.data.date_curr].week,
                form_id: form_id
            };
            //1 == d.data.online_time &&
            //(
                //e.plan_date = d.data.date[d.data.date_curr].date + " " + d.data.time_list[d.data.time_curr].start + "-" + d.data.time_list[d.data.time_curr].end,
                //e.date = d.data.date[d.data.date_curr].date,
                //null != d.data.time_list[d.data.time_curr].shop_member && "" != d.data.time_list[d.data.time_curr].shop_member && (e.shop_member = d.data.time_list[d.data.time_curr].shop_member),
                //null != d.data.time_list[d.data.time_curr].home_member && "" != d.data.time_list[d.data.time_curr].home_member && (e.home_member = d.data.time_list[d.data.time_curr].home_member)
            //),
            app.util.request({
                url: "entry/wxapp/setorder2",
                data: e,
                success: function(ex) {
                    //console.log(ex)
                    var e = ex.data;
                    if ("" != e.data) {
                        wx.showToast({title: "提交成功", icon: "success", duration: 2e3});
                        setTimeout(function () {
                            wx.navigateBack({changed: true});//返回上一页
                            //wx.navigateTo({ url: "../porder/pay?&out_trade_no=" + e.data.out_trade_no });
                        }, 2e3);
                    }
                },
                fail:function(ex){
                    var e = ex.data;
                    if("" != e && "" != e.message){
                        wx.showModal({
                            title: "提示",
                            showCancel:false,
                            content: e.message
                        });
                    }
                    console.log(ex)
                }
            });
        }
    },
    onLoad: function(a) {
        var i = this;
        var clone= a.clone? a.clone:0
        common.config(i),common.theme(i);
        //console.log(i.data.config)
        app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "detail",
                out_trade_no: a.out_trade_no
            },
            success: function (a) {
                var t = a.data.data
                if ("" == t) {
                    i.setData({
                        startDate:new Date().Format("MM月dd日"),
                        startTime:new Date().Format("HH:mm"),
                        clone:clone
                    })
                }else{
                    var userName = ( undefined != t.userinfo.name && "" != t.userinfo.name ) ? t.userinfo.name : "",
                    mobile = ( undefined != t.userinfo.mobile && "" != t.userinfo.mobile) ? t.userinfo.mobile : "",
                    startDate = t.service_time_tip.split(' ')[0],
                    startTime = t.service_time_tip.split(' ')[1],
                    now = new Date(nowYear + '/' + startDate.replace('月', '/').replace('日', '') + ' ' + startTime),
                    entTime = now.setMinutes(now.getMinutes() + parseInt(t.service_time));
                    entTime = new Date(entTime).Format("MM月dd日 HH:mm");
                    var service_id = t.pid,
                    service_name = t.service_name,
                    service_time = ""!=t.service_time ? parseInt(t.service_time) : 30;
                    if ("" != mobile) mobile = mobile.substr(0, 2) + "*****" + mobile.substr(7);
                    if (clone == 1) {
                        service_id = ""
                        service_name = ""
                        service_time = ""
                        startTime = entTime.split(' ')[1];
                        var now1 = new Date(nowYear + '/' + startDate.replace('月', '/').replace('日', '') + ' ' + startTime);
                        entTime = now1.setMinutes(now1.getMinutes() + parseInt(t.service_time));
                        entTime = new Date(entTime).Format("MM月dd日 HH:mm");
                    }
                    var x = 0;
                    for (x = 4; x > 0; x--) {
                        if (i.data.date[x]['date'] == startDate) {
                            break;
                        }
                    }

                    "" != t && i.setData({
                        order: t,
                        o_amount: t.amount,
                        service_id: service_id,
                        service_name: service_name,
                        service_time: service_time,
                        member_name: t.member_list.name,
                        member_id: t.member_list.id,
                        name: userName,
                        mobile: mobile,
                        startDate: startDate,
                        startTime: startTime,
                        end_time: entTime,
                        date_curr: x,
                        clone: clone
                    })
                }
            }
        })
        if ("" == i.data.config) {
            var t = null
        }
        var date_curr = 0;
        for (var t = [], e = 0; e < 5; e++) {
            (s = {}).index = e, s.date = GetDateStr(e), s.week = getMyDay(e), s.name = 0 == e ? "今天" : getMyDay2(e), 
            t.push(s);
        }
        if (i.setData({
            date: t
        }), "" != a.id && null != a.id) i.setData({
            id: a.id
        }); else {
            var d = ( undefined!=app.map ) ? app.map :""
            // todo d.map一直是空
            var r = -1;
            null != d && "" != d && "" != d.content && null != d.content && 1 == d.content.store && (r = ""), 
            i.setData({
                id: r,
                map: d
            });
        }
        var s = {
            op: "store_order"
        };
        "" != i.data.id && null != i.data.id && -1 != i.data.id && (s.id = i.data.id), app.util.request({
            url: "entry/wxapp/service",
            data: s,
            success: function(t) {
                var e = t.data;
                "" != e.data && ("" != e.data.list && null != e.data.list && i.setData({
                    list: e.data.list,
                    id: e.data.list.id
                }), "" != a.member_id && null != a.member_id && "" != a.member_name && null != a.member_name && i.setData({
                    member_id: a.member_id,
                    member_name: a.member_name
                }), "" != e.data.times && null != e.data.times && (i.setData({
                    times: e.data.times
                }), get_time(i)), i.setData({
                    more_store: e.data.more_store
            }));
            }
        });
        var n = i.data.config, o = -1, m = -1;
        "" != n && null != n && ("" != n.home_status && null != n.home_status && (o = n.home_status), 
        "" != n.online_time && null != n.online_time && (m = n.online_time)), i.setData({
            home_status: o,
            online_time: m
        }), -1 == o && i.setData({
            service_type: 2
        });
        i.setData({service_type:2});
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        a.setData({
            shadow: !0,
        })
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var a = this;
        !a.data.isbottom && a.data.member_page && app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "store_member",
                id: a.data.id,
                page: a.data.page,
                pagesize: a.data.pagesize
            },
            success: function(t) {
                var e = t.data;
                "" != e.data ? a.setData({
                    member_list: a.data.member_list.concat(e.data),
                    page: a.data.page
                }) : a.setData({
                    isbottom: !0
                });
            }
        });
    }


});
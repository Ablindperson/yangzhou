var app = getApp(), common = require("../common/common.js");

function GetDateStr(t) {
    var e = new Date();
    e.setDate(e.getDate() + t);
    e.getFullYear();
    return e.getMonth() + 1 + "月" + e.getDate() + "日";
}

function getMyDay(t) {
    var e = new Date();
    return e.setDate(e.getDate() + t), 0 == e.getDay() && "周日", 1 == e.getDay() && "周一", 
    2 == e.getDay() && "周二", 3 == e.getDay() && "周三", 4 == e.getDay() && "周四", 5 == e.getDay() && "周五", 
    6 == e.getDay() && "周六", e.getDay();
}

function getMyDay2(t) {
    var e, a = new Date();
    return a.setDate(a.getDate() + t), 0 == a.getDay() && (e = "周日"), 1 == a.getDay() && (e = "周一"), 
    2 == a.getDay() && (e = "周二"), 3 == a.getDay() && (e = "周三"), 4 == a.getDay() && (e = "周四"), 
    5 == a.getDay() && (e = "周五"), 6 == a.getDay() && (e = "周六"), e;
}

function get_time(i) {
    var d = i.data.times, r = [], s = !1;
    i.setData({
        time_list: s,
        tip: s
    }), 1 == i.data.online_time && app.util.request({
        url: "entry/wxapp/user",
        showLoading: !1,
        data: {
            op: "plan_date",
            plan_date: i.data.date[i.data.date_curr].date,
            id: i.data.id
        },
        success: function(t) {
            var e = t.data;
            if ("" != e.data) {
                if (1 == e.data.status) for (var a = 0; a < d.length; a++) d[a].week == i.data.date[i.data.date_curr].week ? r = d[a].content : 7 == d[a].week && 0 == i.data.date[i.data.date_curr].week && (r = d[a].content); else s = !0;
                "" != i.data.member_id && null != i.data.member_id ? app.util.request({
                    url: "entry/wxapp/user",
                    data: {
                        op: "times_log",
                        member: i.data.member_id,
                        plan_date: i.data.date[i.data.date_curr].date,
                        list: JSON.stringify(r),
                        index: i.data.date[i.data.date_curr].index
                    },
                    success: function(t) {
                        var e = t.data;
                        "" != e.data ? i.setData({
                            tip: s,
                            time_curr: -1,
                            time_list: e.data
                        }) : i.setData({
                            tip: s,
                            time_curr: -1,
                            time_list: r
                        });
                    }
                }) : i.setData({
                    time_curr: -1,
                    time_list: r,
                    tip: s
                });
            }
        }
    });
}

function sign(t) {
    var e = t.data.time_curr, a = t.data.name, i = (t.data.mobile, t.data.member_id), d = t.data.service_id, r = t.data.service_type, s = "";
    1 == t.data.online_time && -1 == e && (s = "请选择时间"), "" != a && null != a || (s = "请填写预约人信息"),
    "" != i && null != i || (s = "请选择服务人员"), "" != d && null != d || (s = "请选择服务项目"), 
    -1 == r && (s = "请选择服务方式"), "" == s ? t.setData({
        submit: !0
    }) : wx.showModal({
        title: "提示",
        showCancel:false,
        content: s
    });
}

Page({
    data: {
        pagePath: "../store/porder",
        date_curr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        submit: !1,
        time_curr: -1,
        service_type: -1
    },
    tab: function(t) {
        var e = this, a = (e.data.service_home, t.currentTarget.dataset.index);
        if (undefined != e.data.service_home) {
            var g = e.data.service_home.home;
            if (-1 == g && 1 == a) {
                wx.showModal({
                    title: "提示",
                    showCancel:false,
                    content: "团购暂不支持上门服务"
                });
                return;
            }
        }
        a != e.data.service_type && (1 == a ? e.setData({
            member_id: -2,
            member_name: "店内安排"
        }) : e.setData({
            member_id: null,
            member_name: null
        }), e.setData({
            service_type: a
        }), get_time(e));
    },
    qie: function() {
        var i = this;
        1 == i.data.more_store && -1 != i.data.id && (i.setData({
            store_page: !0,
            store_list: []
        }), wx.getLocation({
            type: "wgs84",
            success: function(t) {
                var e = t.latitude, a = t.longitude;
                t.speed, t.accuracy;
                i.setData({
                    latitude: e,
                    longitude: a
                });
            },
            complete: function() {
                var t = {
                    op: "store",
                    page: i.data.page,
                    pagesize: i.data.pagesize
                };
                null != i.data.latitude && "" != i.data.latitude && (t.latitude = i.data.latitude), 
                null != i.data.longitude && "" != i.data.longitude && (t.longitude = i.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/order",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data && (i.setData({
                            store_list: e.data
                        }), get_time(i));
                    }
                });
            }
        }));
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        e.setData({
            list: e.data.store_list[a],
            id: e.data.store_list[a].id,
            store_page: !1
        }), 1 != e.data.service_type && e.setData({
            member_id: ""
        }), get_time(e);
    },
    call: function(t) {
        var e = this;
        null != e.data.id && "" != e.data.id && (-1 == e.data.id ? wx.makePhoneCall({
            phoneNumber: e.data.map.content.mobile
        }) : wx.makePhoneCall({
            phoneNumber: e.data.list.mobile
        }));
    },
    map: function(t) {
        var e = this;
        null != e.data.id && "" != e.data.id && (-1 == e.data.id ? wx.openLocation({
            latitude: parseFloat(e.data.map.content.latitude),
            longitude: parseFloat(e.data.map.content.longitude),
            name: e.data.map.content.address,
            address: e.data.map.content.address,
            scale: 28
        }) : wx.openLocation({
            latitude: parseFloat(e.data.list.map.latitude),
            longitude: parseFloat(e.data.list.map.longitude),
            name: e.data.list.address,
            address: e.data.list.address,
            scale: 28
        }));
    },
    date_choose: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        a != e.data.date_curr && (e.setData({
            date_curr: a,
            time_curr: -1
        }), get_time(e));
    },
    date_left: function() {
        var t = this;
        if (0 < t.data.date_curr) t.setData({
            date_curr: t.data.date_curr - 1,
            time_curr: -1
        }), get_time(t); else {
            var e = t.data.date;
            if (0 < e[t.data.date_curr].index) {
                var a = {};
                a.index = e[t.data.date_curr].index - 1, a.date = GetDateStr(a.index), a.week = getMyDay(a.index), 
                0 == a.index ? a.name = "今天" : a.name = getMyDay2(a.index), e.splice(e.length - 1, 1), 
                e.unshift(a), t.setData({
                    date: e,
                    time_curr: -1
                }), get_time(t);
            }
        }
    },
    date_right: function() {
        var t = this;
        if (t.data.date_curr < t.data.date.length - 1) t.setData({
            date_curr: t.data.date_curr + 1,
            time_curr: -1
        }), get_time(t); else {
            var e = t.data.date, a = {};
            a.index = e[t.data.date_curr].index + 1, a.date = GetDateStr(a.index), a.week = getMyDay(a.index), 
            0 == a.index ? a.name = "今天" : a.name = getMyDay2(a.index), e.splice(0, 1), e.push(a), 
            t.setData({
                date: e,
                time_curr: -1
            }), get_time(t);
        }
    },
    time_choose: function(t) {
        var a = t.currentTarget.dataset.index;
        var d = this.data.time_list[a];
        if ( undefined == this.data.service_name || "" == this.data.service_name ) {
            wx.showModal({
                //title: "提示",
                content:"请先选择【服务项目】",
                showCancel:false,
                confirmText:"朕知道了"
            })
            return;
        }
        if ( undefined == this.data.member_name || "" == this.data.member_name) {
            wx.showModal({
                //title: "提示",
                content:"请先选择【服务人员】",
                showCancel:false,
                confirmText:"朕知道了"
            })
            return;
        }
        a != this.data.time_curr && this.setData({
            time_curr: a
        });

        //上门服务不需要预约时长估算 2018-09-25
        if (1 == this.data.service_type) return;

        var content = "";
        if ( d.total > 0 ) {
            content = "该时间段，前面已有"+ d.total+"人预约";
        }
        if (d.service_time > 0){
            var hour =  Math.floor(d.service_time / 60);
            var time1content = (hour>0)?hour+"小时":"";
            var minute = d.service_time % 60;
            time1content = time1content + ( minute>0 ? minute + "分钟":"");
            var tempStrs = d.start.split(":");  //截取时间
            var minute1 =  tempStrs[1] + minute  ;
            var hour1 = tempStrs[0] * 1 +  hour + Math.floor( minute1 / 60 ) ;
            minute1 = minute1 % 60;
            if (minute1 < 10) {
                minute1 = "0" + minute1;
            }
            content = content + "，预计服务时长"+ time1content +"，请于" + hour1+":"+ minute1 +"左右到店。若时间不便，请预约其他时间或技师";
        }else{
            content = "恭喜您！该时间段，前面无人预约，请于"+ d.start.replace(/\b(09)/gi,"9")+"进店接受服务！"
        }

        if( "" != content ) {
            wx.showModal({
                title: "提示",
                content:content,
                showCancel:false,
                confirmText:"朕知道了"
            })
        }
    },

    member_on: function() {
        //选择技师接口
        var a = this;
        if ("" != a.data.id && null != a.data.id) {
            if (1 != a.data.service_type) {
                a.setData({
                    member_page: !0
                });
                var t = {
                    op: "store_member",
                    pid: a.data.service_id,
                    id: a.data.id,
                    page: a.data.page,
                    pagesize: a.data.pagesize
                };
                "" != a.data.service_id && null != a.data.service_id && (t.service = a.data.service_id), 
                app.util.request({
                    url: "entry/wxapp/index",
                    data: t,
                    success: function(t) {
                        var e = t.data;
                        "" != e.data ? a.setData({
                            member_list: e.data,
                            page: a.data.page
                        }) : a.setData({
                            isbottom: !0
                        });
                    }
                });
            }
        } else wx.showModal({
            title: "提示",
            showCancel:false,
            content: "请先选择门店",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    member_close: function() {
        this.setData({
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        });
    },
    member_choose: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.member_list;
        this.setData({
            member_id: a[e].id,
            member_name: a[e].name,
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        }), get_time(this);
    },
    service_on: function() {
        var a = this;
        if ("" != a.data.id && null != a.data.id) {
            a.setData({
                shadow: !1,
                service_page: !0
            });
            var t = {
                op: "store_service",
                id: a.data.id
            };
            "" != a.data.member_id && null != a.data.member_id && (t.member = a.data.member_id), 
            -1 != a.data.service_type && (t.service_type = a.data.service_type), app.util.request({
                url: "entry/wxapp/index",
                data: t,
                success: function(t) {
                    var e = t.data;
                    "" != e.data && a.setData({
                        service_list: e.data
                    });
                }
            });
        } else wx.showModal({
            title: "提示",
            showCancel:false,
            content: "请先选择门店",
            success: function(t) {
                t.confirm ? console.log("用户点击确定") : t.cancel && console.log("用户点击取消");
            }
        });
    },
    service_close: function() {
        this.setData({
            shadow: !0,
            service_page: !1,
            service_list: []
        });
    },
    service_choose: function(t) {
        var e = t.currentTarget.dataset.index, a = this.data.service_list;
        this.setData({
            shadow: !0,
            service_page: !1,
            service_id: a[e].id,
            service_name: a[e].name,
            service_home: a[e],
            service_list: []
        });
    },
    reset: function(t) {
        var e = t.currentTarget.dataset.index;
        1 == e ? (this.setData({
            member_id: null,
            member_name: null
        }), get_time(this)) : 2 == e && this.setData({
            service_id: null,
            service_name: null
        });
    },
    submit: function() {
        var t = this;
        //t.data.service_type = t.data.service_type === -1 ? 2 : t.data.service_type
        if (sign(t), t.data.submit) {
            var e = {
                id: t.data.service_id,
                total: 1,
                name: t.data.name,
                mobile: t.data.mobile,
                store: t.data.id,
                member: t.data.member_id,
                service_type: t.data.service_type,
                order_type: 4
            };
            1 == t.data.online_time && (e.plan_date = t.data.date[t.data.date_curr].date + " " + t.data.time_list[t.data.time_curr].start + "-" + t.data.time_list[t.data.time_curr].end, 
            e.date = t.data.date[t.data.date_curr].date, null != t.data.time_list[t.data.time_curr].shop_member && "" != t.data.time_list[t.data.time_curr].shop_member && (e.shop_member = t.data.time_list[t.data.time_curr].shop_member), 
            null != t.data.time_list[t.data.time_curr].home_member && "" != t.data.time_list[t.data.time_curr].home_member && (e.home_member = t.data.time_list[t.data.time_curr].home_member)), 
            app.util.request({
                url: "entry/wxapp/setorder",
                data: e,
                success: function(t) {
                    var e = t.data;
                    "" != e.data && (wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        wx.navigateTo({
                            url: "../porder/pay?&out_trade_no=" + e.data.out_trade_no
                        });
                    }, 2e3));
                }
            });
        }
    },
    onLoad: function(a) {
        var i = this;
        common.config(i),common.theme(i);
        if ("" == i.data.config) {
            var t = null
            //common.login(n),
            app.util.request({
                url: "entry/wxapp/index",
                data: {
                    op: "base"
                },
                showLoading: !1,
                success: function (e) {
                    var a = e.data, n = 1;
                    var baseurl = e.data.data.theme.content.homepage;
                    "" != a.data && ("" != a.data.config && null != a.data.config && (app.config = a.data.config) && (i.setData({config: a.data.config.content})),
                    "" != a.data.theme && null != a.data.theme && (app.theme = a.data.theme, "" != a.data.theme.content && null != a.data.theme.content && 3 == a.data.theme.content.theme && (n = 3)),
                    "" != a.data.map && null != a.data.map && (app.map = a.data.map), "" != a.data.share && null != a.data.share && (app.share = a.data.share));

                    //
                    var n = i.data.config, o = 1, m = 1;
                    "" != n && null != n && ("" != n.home_status && null != n.home_status && (o = n.home_status),
                    "" != n.online_time && null != n.online_time && (m = n.online_time)), i.setData({
                        home_status: o,
                        online_time: m
                    }), -1 == o && i.setData({
                        service_type: 2
                    });
                    i.setData({service_type:2});

                }
            })
        }

        for (var t = [], e = 0; e < 5; e++) {
            (s = {}).index = e, s.date = GetDateStr(e), s.week = getMyDay(e), s.name = 0 == e ? "今天" : getMyDay2(e), 
            t.push(s);
        }
        if (i.setData({
            date: t
        }), "" != a.id && null != a.id) i.setData({
            id: a.id
        }); else {
            var d = ( app.map )? app.map :""
            // todo d.map一直是空
            var r = -1;
            null != d && "" != d && "" != d.content && null != d.content && 1 == d.content.store && (r = ""), 
            i.setData({
                id: r,
                map: d
            });
        }
        var s = {
            op: "store_order"
        };
        "" != i.data.id && null != i.data.id && -1 != i.data.id && (s.id = i.data.id), app.util.request({
            url: "entry/wxapp/service",
            data: s,
            success: function(t) {
                var e = t.data;
                "" != e.data && ("" != e.data.list && null != e.data.list && i.setData({
                    list: e.data.list,
                    id: e.data.list.id
                }), "" != a.member_id && null != a.member_id && "" != a.member_name && null != a.member_name && i.setData({
                    member_id: a.member_id,
                    member_name: a.member_name
                }), "" != e.data.times && null != e.data.times && (i.setData({
                    times: e.data.times
                }), get_time(i)), i.setData({
                    more_store: e.data.more_store
                }));
            }
        });
        var n = i.data.config, o = -1, m = -1;
        "" != n && null != n && ("" != n.home_status && null != n.home_status && (o = n.home_status), 
        "" != n.online_time && null != n.online_time && (m = n.online_time)), i.setData({
            home_status: o,
            online_time: m
        }), -1 == o && i.setData({
            service_type: 2
        });
        i.setData({service_type:2});
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        app.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "address_default"
            },
            success: function(t) {
                var e = t.data;
                if ("" != e.data) {
                    e.data.address;
                    "" != e.data.content && null != e.data.content && e.data.content, a.setData({
                        name: e.data.name,
                        mobile: e.data.mobile,
                        address: e.data.address,
                        content: e.data.content,
                    });
                }
            }
        });
        a.setData({
            shadow: !0,
        })
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var a = this;
        !a.data.isbottom && a.data.member_page && app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "store_member",
                id: a.data.id,
                page: a.data.page,
                pagesize: a.data.pagesize
            },
            success: function(t) {
                var e = t.data;
                "" != e.data ? a.setData({
                    member_list: a.data.member_list.concat(e.data),
                    page: a.data.page
                }) : a.setData({
                    isbottom: !0
                });
            }
        });
    }
});
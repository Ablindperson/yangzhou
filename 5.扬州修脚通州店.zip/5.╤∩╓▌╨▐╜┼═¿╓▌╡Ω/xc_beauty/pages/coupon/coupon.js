var app = getApp(), common = require("../common/common.js");

Page({
    data: {
        curr: -1,
        //noauth:1,
        list:[]
    },
    tab: function(t) {
        var n = this, a = t.currentTarget.dataset.index;
        a != n.data.curr && (n.setData({
            curr: a,
            list: []
        }), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                ct:2,
                curr: n.data.curr
            },
            success: function(t) {
                var a = t.data;
                "" != a.data && 1!= a.data.noauth && n.setData({
                    list: a.data,
                    noauth:0
                });
                "" != a.data && 1== a.data.noauth && n.setData({
                    noauth:1
                });
            }
        }));
    },
    reload:function(t){
        var n=this
        var ct= t ? t : 1;
        var i=setInterval(function(){
            //console.log("setinterval..ct:"+ct)
            wx.getStorage({//获取本地缓存
                key:"userInfo",
                success:function(res){
                    app.util.request({
                        url: "entry/wxapp/index",
                        data: {
                            op: "coupon",
                            ct:ct,
                            curr: n.data.curr
                        },
                        success: function(t1) {
                            var a = t1.data;
                            var noauth =  a.data.noauth ?  a.data.noauth : -1;
                            "" != a.data && 1!=a.data.noauth && n.setData({
                                list: a.data,
                            });
                        },
                    });
                    clearInterval(i)
                },
            })
        },1500)
        setTimeout(function(){
            clearInterval(i)
        },30000)
    },
    onLoad: function(t) {
        var n = this;
        if (undefined == t || undefined == t.ct || null == t) {
            var t=null
        }
        var ct = ( undefined == t || undefined == t.ct || null == t ) ? -1 : t.ct;
        common.config(n), common.theme(n), app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "coupon",
                ct:ct,
                curr: n.data.curr
            },
            success: function(t1) {
                var a = t1.data;
                var noauth =  a.data.noauth ?  a.data.noauth : -1;
                "" != a.data && 1!=a.data.noauth && n.setData({
                    list: a.data,
                });
                if ( "503-Auth"==a.message ){
                    n.reload(ct)
                }
            },
        });

    },
    toService: function(t) {
        if (1==t.currentTarget.dataset.isexp) {
            wx.showToast({
              title: '已经过期了',icon: "success",duration: 850
            })
            return
        }

        wx.navigateTo({
          url: "../../ui2/service/service"
        })
    },
    toHome: function() {
        wx.redirectTo({
            url: "../../ui2/index/index"
        })
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
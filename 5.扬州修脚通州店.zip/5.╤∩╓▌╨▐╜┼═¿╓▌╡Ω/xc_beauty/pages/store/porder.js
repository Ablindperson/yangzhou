var app = getApp(), common = require("../common/common.js");

function GetDateStr(a) {
    var t = new Date();
    t.setDate(t.getDate() + a);
    t.getFullYear();
    return t.getMonth() + 1 + "月" + t.getDate() + "日";
}

function getMyDay(a) {
    var t = new Date();
    return t.setDate(t.getDate() + a), 0 == t.getDay() && "周日", 1 == t.getDay() && "周一", 
    2 == t.getDay() && "周二", 3 == t.getDay() && "周三", 4 == t.getDay() && "周四", 5 == t.getDay() && "周五", 
    6 == t.getDay() && "周六", t.getDay();
}

function getMyDay2(a) {
    var t, e = new Date();
    return e.setDate(e.getDate() + a), 0 == e.getDay() && (t = "周日"), 1 == e.getDay() && (t = "周一"), 
    2 == e.getDay() && (t = "周二"), 3 == e.getDay() && (t = "周三"), 4 == e.getDay() && (t = "周四"), 
    5 == e.getDay() && (t = "周五"), 6 == e.getDay() && (t = "周六"), t;
}

function get_time(i) {
    var d = i.data.times, s = [], n = !1;
    i.setData({
        time_list: n,
        tip: n
    }), 1 == i.data.online_time && app.util.request({
        url: "entry/wxapp/user",
        showLoading: !1,
        data: {
            op: "plan_date",
            plan_date: i.data.date[i.data.date_curr].date,
            id: i.data.id
        },
        success: function(a) {
            var t = a.data;
            if ("" != t.data) {
                if (1 == t.data.status) {
                    for (var e = 0; e < d.length; e++) d[e].week == i.data.date[i.data.date_curr].week ? s = d[e].content : 7 == d[e].week && 0 == i.data.date[i.data.date_curr].week && (s = d[e].content);
                    app.util.request({
                        url: "entry/wxapp/user",
                        data: {
                            op: "times_log",
                            plan_date: i.data.date[i.data.date_curr].date,
                            list: JSON.stringify(s),
                            index: i.data.date[i.data.date_curr].index
                        },
                        success: function(a) {
                            var t = a.data;
                            "" != t.data ? i.setData({
                                time_curr: -1,
                                time_list: t.data
                            }) : i.setData({
                                time_curr: -1,
                                time_list: s
                            });
                        }
                    });
                } else n = !0;
                i.setData({
                    time_list: s,
                    tip: n
                });
            }
        }
    });
}

function sign(a) {
    var t = a.data.time_curr, e = a.data.name, i = a.data.mobile, d = a.data.member_id, s = a.data.service_id, n = !0;
    1 == a.data.online_time && -1 == t && (n = !1), "" != e && null != e || (n = !1), 
    "" != i && null != i || (n = !1);
    /^(((13[0-9]{1})|(14[0-9]{1})|(17[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(18[0-9]{1}))+\d{8})$/.test(i) || (n = !1), 
    "" != d && null != d && "" != s && null != s || (n = !1), a.setData({
        submit: n
    });
}

Page({
    data: {
        pagePath: "../store/porder",
        date_curr: 0,
        page: 1,
        pagesize: 20,
        isbottom: !1,
        submit: !1,
        time_curr: -1
    },
    qie: function() {
        var i = this;
        -1 != i.data.id && (i.setData({
            store_page: !0,
            store_list: []
        }), wx.getLocation({
            type: "wgs84",
            success: function(a) {
                var t = a.latitude, e = a.longitude;
                a.speed, a.accuracy;
                i.setData({
                    latitude: t,
                    longitude: e
                });
            },
            complete: function() {
                var a = {
                    op: "store",
                    page: i.data.page,
                    pagesize: i.data.pagesize
                };
                null != i.data.latitude && "" != i.data.latitude && (a.latitude = i.data.latitude), 
                null != i.data.longitude && "" != i.data.longitude && (a.longitude = i.data.longitude), 
                app.util.request({
                    url: "entry/wxapp/order",
                    data: a,
                    success: function(a) {
                        var t = a.data;
                        "" != t.data && i.setData({
                            store_list: t.data
                        });
                    }
                });
            }
        }));
    },
    store_close: function() {
        this.setData({
            store_page: !1
        });
    },
    store_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        t.setData({
            list: t.data.store_list[e],
            id: t.data.store_list[e].id,
            store_page: !1,
            member_id: "",
            service_id: ""
        }), sign(t);
    },
    call: function(a) {
        var t = this;
        null != t.data.id && "" != t.data.id && (-1 == t.data.id ? wx.makePhoneCall({
            phoneNumber: t.data.map.content.mobile
        }) : wx.makePhoneCall({
            phoneNumber: t.data.list.mobile
        }));
    },
    map: function(a) {
        var t = this;
        null != t.data.id && "" != t.data.id && (-1 == t.data.id ? wx.openLocation({
            latitude: parseFloat(t.data.map.content.latitude),
            longitude: parseFloat(t.data.map.content.longitude),
            name: t.data.map.content.address,
            address: t.data.map.content.address,
            scale: 28
        }) : wx.openLocation({
            latitude: parseFloat(t.data.list.map.latitude),
            longitude: parseFloat(t.data.list.map.longitude),
            name: t.data.list.address,
            address: t.data.list.address,
            scale: 28
        }));
    },
    date_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.date_curr && (t.setData({
            date_curr: e,
            time_curr: -1
        }), get_time(t), sign(t));
    },
    date_left: function() {
        var a = this;
        if (0 < a.data.date_curr) a.setData({
            date_curr: a.data.date_curr - 1,
            time_curr: -1
        }), get_time(a), sign(a); else {
            var t = a.data.date;
            if (0 < t[a.data.date_curr].index) {
                var e = {};
                e.index = t[a.data.date_curr].index - 1, e.date = GetDateStr(e.index), e.week = getMyDay(e.index), 
                0 == e.index ? e.name = "今天" : e.name = getMyDay2(e.index), t.splice(t.length - 1, 1), 
                t.unshift(e), a.setData({
                    date: t,
                    time_curr: -1
                }), get_time(a), sign(a);
            }
        }
    },
    date_right: function() {
        var a = this;
        if (a.data.date_curr < a.data.date.length - 1) a.setData({
            date_curr: a.data.date_curr + 1,
            time_curr: -1
        }), get_time(a), sign(a); else {
            var t = a.data.date, e = {};
            e.index = t[a.data.date_curr].index + 1, e.date = GetDateStr(e.index), e.week = getMyDay(e.index), 
            0 == e.index ? e.name = "今天" : e.name = getMyDay2(e.index), t.splice(0, 1), t.push(e), 
            a.setData({
                date: t,
                time_curr: -1
            }), get_time(a), sign(a);
        }
    },
    time_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.time_curr && (t.setData({
            time_curr: e
        }), sign(t));
    },
    member_on: function() {
        var e = this;
        if ("" != e.data.id && null != e.data.id) {
            e.setData({
                member_page: !0
            });
            var a = {
                op: "store_member",
                id: e.data.id,
                page: e.data.page,
                pagesize: e.data.pagesize
            };
            "" != e.data.service_id && null != e.data.service_id && (a.service = e.data.service_id), 
            app.util.request({
                url: "entry/wxapp/index",
                data: a,
                success: function(a) {
                    var t = a.data;
                    "" != t.data ? e.setData({
                        member_list: t.data,
                        page: e.data.page
                    }) : e.setData({
                        isbottom: !0
                    });
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请先选择门店",
            success: function(a) {
                a.confirm ? console.log("用户点击确定") : a.cancel && console.log("用户点击取消");
            }
        });
    },
    member_close: function() {
        this.setData({
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        });
    },
    member_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index, i = t.data.member_list;
        t.setData({
            member_id: i[e].id,
            member_name: i[e].name,
            member_page: !1,
            page: 1,
            isbottom: !1,
            member_list: []
        }), sign(t);
    },
    service_on: function() {
        var e = this;
        if ("" != e.data.id && null != e.data.id) {
            e.setData({
                shadow: !0,
                service_page: !0
            });
            var a = {
                op: "store_service",
                id: e.data.id
            };
            "" != e.data.member_id && null != e.data.member_id && (a.member = e.data.member_id), 
            app.util.request({
                url: "entry/wxapp/index",
                data: a,
                success: function(a) {
                    var t = a.data;
                    "" != t.data && e.setData({
                        service_list: t.data
                    });
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请先选择门店",
            success: function(a) {
                a.confirm ? console.log("用户点击确定") : a.cancel && console.log("用户点击取消");
            }
        });
    },
    service_close: function() {
        this.setData({
            shadow: !1,
            service_page: !1,
            service_list: []
        });
    },
    service_choose: function(a) {
        var t = a.currentTarget.dataset.index, e = this.data.service_list;
        this.setData({
            shadow: !1,
            service_page: !1,
            service_id: e[t].id,
            service_name: e[t].name,
            service_list: []
        }), sign(this);
    },
    reset: function(a) {
        var t = a.currentTarget.dataset.index;
        1 == t ? this.setData({
            member_id: "",
            member_name: ""
        }) : 2 == t && this.setData({
            service_id: "",
            service_name: ""
        }), sign(this);
    },
    submit: function() {
        var a = this;
        if (a.data.submit) {
            var t = {
                id: a.data.service_id,
                total: 1,
                name: a.data.name,
                mobile: a.data.mobile,
                store: a.data.id,
                member: a.data.member_id
            };
            1 == a.data.online_time && (t.date = a.data.date[a.data.date_curr].date, t.plan_date = a.data.date[a.data.date_curr].date + " " + a.data.time_list[a.data.time_curr].start + "-" + a.data.time_list[a.data.time_curr].end), 
            app.util.request({
                url: "entry/wxapp/setorder",
                data: t,
                success: function(a) {
                    var t = a.data;
                    "" != t.data && (wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        wx.navigateTo({
                            url: "../porder/pay?&out_trade_no=" + t.data.out_trade_no
                        });
                    }, 2e3));
                }
            });
        }
    },
    onLoad: function(e) {
        var i = this;
        common.config(i), common.theme(i);
        for (var a = [], t = 0; t < 5; t++) {
            (n = {}).index = t, n.date = GetDateStr(t), n.week = getMyDay(t), n.name = 0 == t ? "今天" : getMyDay2(t), 
            a.push(n);
        }
        if (i.setData({
            date: a
        }), "" != e.id && null != e.id) i.setData({
            id: e.id
        }); else {
            var d = app.map, s = -1;
            null != d && "" != d && "" != d.content && null != d.content && 1 == d.content.store && (s = ""), 
            i.setData({
                id: s,
                map: d
            });
        }
        var n = {
            op: "store_order"
        };
        "" != i.data.id && null != i.data.id && -1 != i.data.id && (n.id = i.data.id), app.util.request({
            url: "entry/wxapp/service",
            data: n,
            success: function(a) {
                var t = a.data;
                "" != t.data && ("" != t.data.list && null != t.data.list && i.setData({
                    list: t.data.list,
                    id: t.data.list.id
                }), "" != e.member_id && null != e.member_id && "" != e.member_name && null != e.member_name && i.setData({
                    member_id: e.member_id,
                    member_name: e.member_name
                }), "" != t.data.times && null != t.data.times && (i.setData({
                    times: t.data.times
                }), get_time(i)), i.setData({
                    more_store: t.data.more_store
                }));
            }
        });
        var r = i.data.config, o = -1;
        "" != r && null != r && "" != r.online_time && null != r.online_time && (o = r.online_time), 
        i.setData({
            online_time: o
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        app.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "address_default"
            },
            success: function(a) {
                var t = a.data;
                if ("" != t.data) {
                    t.data.address;
                    "" != t.data.content && null != t.data.content && t.data.content, e.setData({
                        name: t.data.name,
                        mobile: t.data.mobile
                    }), sign(e);
                }
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var e = this;
        !e.data.isbottom && e.data.member_page && app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "store_member",
                id: e.data.id,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    member_list: e.data.member_list.concat(t.data),
                    page: e.data.page
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
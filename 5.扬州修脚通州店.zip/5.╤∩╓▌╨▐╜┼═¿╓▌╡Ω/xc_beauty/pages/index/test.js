var API_URL = 'https://wpdev.ligentshop.com/api/xcx/test';

Page({
  data: {
    movies: [],
    val: ''
  },
  search: function (e) {
    if (!e.detail.value) return;
    wx.showToast({
      title: '加载中',
      icon: 'loading',
    });
    var value = e.detail.value;
    var that = this;
    // this.setData({
    // 	val:value
    // })
    wx.request({
      url: API_URL + '?id=' + 1, //仅为示例，并非真实的接口地址
      data: {},
      header: {
        'content-type': 'application/x-www-form-urlencode'
      },
      success: function (res) {
        console.log("___",res)
        wx.hideToast();
        var data = res.data;
        that.setData({
          movies: data.subjects
        })
      }
    })

  },
  focus: function (e) {
    this.setData({
      val: ""
    })
  }

});
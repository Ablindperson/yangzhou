var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    onLoad: function(o) {
        common.config(this), common.theme(this);
    },
    onReady: function() {},
    onShow: function() {
        var t = this;
        app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "userinfo"
            },
            success: function(o) {
                var n = o.data;
                "" != n.data && t.setData({
                    userinfo: n.data
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
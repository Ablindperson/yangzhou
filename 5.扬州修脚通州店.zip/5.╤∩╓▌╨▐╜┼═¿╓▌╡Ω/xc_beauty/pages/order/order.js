var app = getApp(), common = require("../common/common.js");

function intervalStart(e) {
    var x = setInterval(function() {
        for (var a = e.data.list, t = 0; t < a.length; t++) -1 == a[t].status && a[t].group != null && (0 < parseInt(a[t].second) ? a[t].second = parseInt(a[t].second) - 1 : 0 < parseInt(a[t].min) ? (a[t].second = 59,
            a[t].min = parseInt(a[t].min) - 1) : 0 < parseInt(a[t].hour) ? (a[t].second = 59,
            a[t].min = 59, a[t].hour = parseInt(a[t].hour) - 1) : a[t].status = 2);
        e.setData({
            list: a
        });
    }, 1e3);
    e.setData({x:x})
}
function intervalEnd(e) {
    clearInterval(e.x)
}

Page({
    data: {
        curr: 1,
        page: 1,
        pagesize: 15,
        isbottom: !1
    },
    tab: function(t) {
        var e = this, a = t.currentTarget.dataset.index;
        //console.log(a);
        intervalEnd(e.data)
        a != e.data.curr && (e.setData({
            curr: a,
            list: [],
            isbottom: !1,
            page: 1
        }), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "order",
                curr: e.data.curr,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(t) {
                var a = t.data;
                if ("" != a.data) {
                    for (var i = 0; i < a.data.length; i++) -1 == a.data[i].status && (a.data[i].hour = parseInt(a.data[i].fail / 3600),
                        a.data[i].min = parseInt((a.data[i].fail - 3600 * a.data[i].hour) / 60), a.data[i].second = a.data[i].fail % 60);
                    e.setData({
                        list: a.data,
                        page: e.data.page + 1
                    }),
                        intervalStart(e)

                } else e.setData({
                    isbottom: !0
                });

                //var b = t.data;
                //console.log('tab')
                //"" != b.data ? e.setData({
                //    list: b.data,
                //    page: e.data.page + 1
                //}) : e.setData({
                //    isbottom: !0
                //});
                //if (a == 1) {
                //    console.log("a1")
                //    intervalEnd(e)
                //}
            }
        }));
    },
    to_detail: function(t) {
        console.log("to_detail")
        var a = t.currentTarget.dataset.index,l = this.data.list,redirUrl = ""
        //console.log(l[a]);

        if (3!=l[a].order_type) redirUrl = "detail?&out_trade_no=" + l[a].out_trade_no
        if (3==l[a].order_type && undefined==l[a].group) redirUrl = "../../ui2/porder/pay?&out_trade_no=" + l[a].out_trade_no
        if (3==l[a].order_type && undefined!=l[a].group && -1 == l[a].status) redirUrl = "../../ui2/porder/pay?&out_trade_no=" + l[a].out_trade_no
        if (3==l[a].order_type && undefined!=l[a].group && -1 != l[a].status) redirUrl = "../group/detail?&id=" + l[a].group+"&t="+l[a].out_trade_no
        //console.log(redirUrl);
        //var redirUrl="detail?&out_trade_no=" + l[a].out_trade_no
        //redirUrl="detail?&id=" + this.data.list[a].id
        wx.navigateTo({
            url: redirUrl
        });
    },

    //wx.navigateTo({
    //url: "../../ui2/porder/porder?&id=" + this.data.list.id + "&group=1"
    //});

    to_order: function(t) {
        var n = t.currentTarget.dataset.index;
        //console.log('to_order')
        //console.log(this.data.list[n].out_trade_no)
        wx.navigateTo({
            url: "../order/detail?&out_trade_no=" + this.data.list[n].out_trade_no
        });
    },

    order_del: function(t) {
        var e = this, n = t.currentTarget.dataset.index;
        wx.showModal({
            title: "提示",
            content: "确定取消订单吗？",
            success: function(t) {
                t.confirm ? app.util.request({
                    url: "entry/wxapp/order",
                    data: {
                        op: "order_del",
                        id: e.data.list[n].id
                    },
                    success: function(t) {
                        if ("" != t.data.data) {
                            wx.showToast({
                                title: "取消成功",
                                icon: "success",
                                duration: 2e3
                            });
                            var a = e.data.list;
                            //a[n].status = 3,e.setData({list:a});
                            a.splice(n, 1), e.setData({list: a});
                        }
                    }
                }) : t.cancel && console.log("用户点击取消");
            }
        });
    },
    menu_on: function(t) {
        var a = t.currentTarget.dataset.index;
        this.setData({
            refund: a,
            shadow: !0,
            menu: !0
        });
    },
    menu_close: function(t) {
        this.setData({
            shadow: !1,
            menu: !1
        });
    },
    input: function(t) {
        this.setData({
            content: t.detail.value
        });
    },
    menu_btn: function() {
        var e = this, t = e.data.content;
        //console.log(e.data.list[e.data.refund].status=2)
        if ("" != t && null != t) {
            e.setData({
                content: "",
                shadow: !1,
                menu: !1
            });
            var a = {
                op: "refund",
                id: e.data.list[e.data.refund].id,
                content: t
            };
            app.util.request({
                url: "entry/wxapp/order",
                data: a,
                success: function(t) {
                    if ("" != t.data.data && ""!= t.data ) {
                        //wx.showToast({
                        //    title: "提交成功",
                        //    icon: "success",
                        //    duration: 2e3
                        //});
                        wx.showModal({
                            title: "提交成功",
                            content: t.data.data.content,
                            showCancel: false,
                            confirmText:"确定",
                            success: function(t) {
                            }
                        });
                        var a = e.data.list;
                        //修改状态
                        a[e.data.refund].status=3,e.setData({list:a})
                        //整行删除
                        //a.splice(e.data.refund, 1), e.setData({
                        //    list: a
                        //});
                    }else{
                        wx.showToast({
                            title: "提交失败",
                            icon: "failure",
                            duration: 2e3
                        });
                    }
                }
            });
        }
    },
    to_discuss: function(t) {
        var a = t.currentTarget.dataset.index;
        wx.navigateTo({
            url: "../discuss/discuss?&out_trade_no=" + this.data.list[a].out_trade_no
        });
    },
    onLoad: function(t) {
        //console.log(t);// {}
        //console.log(t.cht);
        var e = this;
        if (1==t.cht){
            e.setData({
                curr:2,
                page:1
            })
            //e.data.curr = 2;
            //e.data.page = 1;
        }
        common.config(e), common.theme(e), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "order",
                curr: e.data.curr,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(t) {
                var a = t.data;
                //console.log("onload.... op=order curr="+e.data.curr)
                //console.log(a)
                if ("" != a.data) {
                    for (var i = 0; i < a.data.length; i++) -1 == a.data[i].status && (a.data[i].hour = parseInt(a.data[i].fail / 3600),
                        a.data[i].min = parseInt((a.data[i].fail - 3600 * a.data[i].hour) / 60), a.data[i].second = a.data[i].fail % 60), a.data[i].service_time_tip = a.data[i].service_time_tip.substring(0,16);
                    e.setData({
                        list: a.data,
                        page: e.data.page + 1
                    }),
                     intervalStart(e)

                } else e.setData({
                    isbottom: !0
                });

                //"" != a.data ? e.setData({
                //    list: a.data,
                //    page: e.data.page + 1
                //}) : e.setData({
                //    isbottom: !0
                //});
            }
        });
    },
    onReady: function() {},
    onShow: function(t) {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var e = this;
        console.log('ReachBottom')
        e.data.isbottom || app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "order",
                curr: e.data.curr,
                page: e.data.page,
                pagesize: e.data.pagesize
            },
            success: function(t) {
                var a = t.data;
                "" != a.data ? e.setData({
                    list: e.data.list.concat(a.data),
                    page: e.data.page + 1
                }) : e.setData({
                    isbottom: !0
                });
            }
        });
    }
});
var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    onLoad: function(u) {
        common.login(this),
        app.util.request({
            url: "entry/wxapp/index",
            data: {
                op: "base"
            },
            showLoading: !1,
            success: function(e) {
                var a = e.data, n = 1;
                var baseurl=e.data.data.theme.content.homepage;
                "" != a.data && ("" != a.data.config && null != a.data.config && (app.config = a.data.config),
                "" != a.data.theme && null != a.data.theme && (app.theme = a.data.theme, "" != a.data.theme.content && null != a.data.theme.content && 3 == a.data.theme.content.theme && (n = 3)), 
                "" != a.data.map && null != a.data.map && (app.map = a.data.map), "" != a.data.share && null != a.data.share && (app.share = a.data.share));
                var t = app.buy_share;
                if ("" != u.share && null != u.share) {
                    var o = unescape(u.share);
                    wx.redirectTo({
                        url: o,
                        success: function(e) {
                            //console.log(e);
                        },
                        fail: function(e) {
                            console.log(e);
                        }
                    });
                } else "" != t && null != t && "undefined" != t ? wx.navigateTo({
                    url: t
                }) : 3 == n ? wx.redirectTo({
                    url: baseurl
                    //url: "../../ui2/index/index"
                }) : wx.redirectTo({
                    url: "../index/index"
                });
                app.util.request({
                    url: "entry/wxapp/grouprefund",
                    showLoading: !1,
                    success: function(e) {}
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        var e = 1;
        "" != app.theme && null != app.theme && ("" != app.theme.content && null != app.theme.content && 3 == app.theme.content.theme && (e = 3), 
        3 == e ? wx.redirectTo({
            url: "../../ui2/index/index"
        }) : wx.redirectTo({
            url: "../index/index"
        }));
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
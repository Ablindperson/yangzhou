var app = getApp(), common = require("../common/common.js");

function GetDateStr(a) {
    var t = new Date();
    t.setDate(t.getDate() + a);
    t.getFullYear();
    return t.getMonth() + 1 + "月" + t.getDate() + "日";
}

function getMyDay(a) {
    var t = new Date();
    return t.setDate(t.getDate() + a), 0 == t.getDay() && "周日", 1 == t.getDay() && "周一", 
    2 == t.getDay() && "周二", 3 == t.getDay() && "周三", 4 == t.getDay() && "周四", 5 == t.getDay() && "周五", 
    6 == t.getDay() && "周六", t.getDay();
}

function getMyDay2(a) {
    var t, e = new Date();
    return e.setDate(e.getDate() + a), 0 == e.getDay() && (t = "周日"), 1 == e.getDay() && (t = "周一"), 
    2 == e.getDay() && (t = "周二"), 3 == e.getDay() && (t = "周三"), 4 == e.getDay() && (t = "周四"), 
    5 == e.getDay() && (t = "周五"), 6 == e.getDay() && (t = "周六"), t;
}

function get_time(e) {
    var a = e.data.times, d = [];
    if (1 == e.data.time_status) {
        for (var t = 0; t < a.length; t++) a[t].week == e.data.date[e.data.date_curr].week ? d = a[t].content : 7 == a[t].week && 0 == e.data.date[e.data.date_curr].week && (d = a[t].content);
        app.util.request({
            url: "entry/wxapp/user",
            data: {
                op: "times_log",
                plan_date: e.data.date[e.data.date_curr].date,
                list: JSON.stringify(d),
                index: e.data.date[e.data.date_curr].index
            },
            success: function(a) {
                var t = a.data;
                "" != t.data ? e.setData({
                    time_curr: -1,
                    time_list: t.data
                }) : e.setData({
                    time_curr: -1,
                    time_list: d
                });
            }
        });
    }
}

function sign(a) {
    var t = a.data.time_curr, e = a.data.name, d = a.data.mobile, r = !0;
    1 == a.data.time_status && -1 == t && (r = !1), "" != e && null != e || (r = !1), 
    "" != d && null != d || (r = !1);
    /^(((13[0-9]{1})|(14[0-9]{1})|(17[0-9]{1})|(15[0-3]{1})|(15[5-9]{1})|(18[0-9]{1}))+\d{8})$/.test(d) || (r = !1), 
    a.setData({
        submit: r
    });
}

Page({
    data: {
        total: 1,
        date_curr: 0,
        time_curr: -1,
        submit: !1
    },
    up: function() {
        this.setData({
            total: this.data.total + 1
        });
    },
    down: function() {
        var a = this;
        1 < a.data.total && a.setData({
            total: a.data.total - 1
        });
    },
    date_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.date_curr && (t.setData({
            date_curr: e,
            time_curr: -1
        }), get_time(t), sign(t));
    },
    date_left: function() {
        var a = this;
        if (0 < a.data.date_curr) a.setData({
            date_curr: a.data.date_curr - 1,
            time_curr: -1
        }), get_time(a), sign(a); else {
            var t = a.data.date;
            if (0 < t[a.data.date_curr].index) {
                var e = {};
                e.index = t[a.data.date_curr].index - 1, e.date = GetDateStr(e.index), e.week = getMyDay(e.index), 
                0 == e.index ? e.name = "今天" : e.name = getMyDay2(e.index), t.splice(t.length - 1, 1), 
                t.unshift(e), a.setData({
                    date: t,
                    time_curr: -1
                }), get_time(a), sign(a);
            }
        }
    },
    date_right: function() {
        var a = this;
        if (a.data.date_curr < a.data.date.length - 1) a.setData({
            date_curr: a.data.date_curr + 1,
            time_curr: -1
        }), get_time(a), sign(a); else {
            var t = a.data.date, e = {};
            e.index = t[a.data.date_curr].index + 1, e.date = GetDateStr(e.index), e.week = getMyDay(e.index), 
            0 == e.index ? e.name = "今天" : e.name = getMyDay2(e.index), t.splice(0, 1), t.push(e), 
            a.setData({
                date: t,
                time_curr: -1
            }), get_time(a), sign(a);
        }
    },
    time_choose: function(a) {
        var t = this, e = a.currentTarget.dataset.index;
        e != t.data.time_curr && (t.setData({
            time_curr: e
        }), sign(t));
    },
    input: function(a) {
        var t = this;
        switch (a.currentTarget.dataset.name) {
          case "name":
            t.setData({
                name: a.detail.value
            });
            break;

          case "mobile":
            t.setData({
                mobile: a.detail.value
            });
            break;

          case "address":
            t.setData({
                address: a.detail.value
            });
        }
        sign(t);
    },
    map: function() {
        var t = this;
        wx.chooseLocation({
            success: function(a) {
                t.setData({
                    address: a.address,
                    map: a
                }), sign(t);
            }
        });
    },
    submit: function() {
        var a = this;
        if (a.data.submit) {
            var t = {
                id: a.data.id,
                total: a.data.total,
                name: a.data.name,
                mobile: a.data.mobile
            };
            "" != a.data.address && null != a.data.address && "undefined" != a.data.address && (t.address = a.data.address), 
            "" != a.data.map && null != a.data.map && "undefined" != a.data.map && (t.map = JSON.stringify(a.data.map)), 
            null != a.data.kind && null != a.data.kind && (t.kind = a.data.kind), "" != a.data.group && null != a.data.group && (t.group = a.data.group), 
            "" != a.data.group_id && null != a.data.group_id && (t.group_id = a.data.group_id), 
            "" != a.data.flash && null != a.data.flash && (t.flash = a.data.flash), 1 == a.data.time_status && (t.date = a.data.date[a.data.date_curr].date, 
            t.plan_date = a.data.date[a.data.date_curr].date + " " + a.data.time_list[a.data.time_curr].start + "-" + a.data.time_list[a.data.time_curr].end), 
            app.util.request({
                url: "entry/wxapp/setorder",
                data: t,
                success: function(a) {
                    var t = a.data;
                    "" != t.data && (wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3
                    }), setTimeout(function() {
                        wx.redirectTo({
                            url: "pay?&out_trade_no=" + t.data.out_trade_no
                        });
                    }, 2e3));
                }
            });
        }
    },
    onLoad: function(d) {
        var r = this;
        common.config(r), common.theme(r), "" != d.id && null != d.id && r.setData({
            id: d.id
        }), "" != d.kind && null != d.kind && r.setData({
            kind: d.kind
        }), "" != d.group && null != d.group && r.setData({
            group: d.group
        }), "" != d.group_id && null != d.group_id && r.setData({
            group_id: d.group_id
        }), "" != d.flash && null != d.flash && r.setData({
            flash: d.flash
        });
        for (var a = [], t = 0; t < 5; t++) {
            var e = {};
            e.index = t, e.date = GetDateStr(t), e.week = getMyDay(t), e.name = 0 == t ? "今天" : getMyDay2(t), 
            a.push(e);
        }
        r.setData({
            date: a
        }), app.util.request({
            url: "entry/wxapp/service",
            data: {
                op: "porder",
                id: d.id
            },
            success: function(a) {
                var t = a.data;
                if ("" != t.data) {
                    if ("" != t.data.service && null != t.data.service) {
                        if ("" != d.kind && null != d.kind && null != t.data.service.parameter && null != t.data.service.parameter) for (var e = 0; e < t.data.service.parameter.length; e++) t.data.service.parameter[e].name == d.kind && "" != t.data.service.parameter[e].price && null != t.data.service.parameter[e].price && (t.data.service.price = t.data.service.parameter[e].price);
                        r.setData({
                            service: t.data.service
                        });
                    }
                    "" != t.data.times && null != t.data.times && (r.setData({
                        times: t.data.times
                    }), get_time(r));
                }
            }
        });
        var i = r.data.config, n = -1;
        "" != i && null != i && "" != i.time_status && null != i.time_status && (n = i.time_status), 
        r.setData({
            time_status: n
        });
    },
    onReady: function() {},
    onShow: function() {
        var d = this;
        app.util.request({
            url: "entry/wxapp/service",
            showLoading: !1,
            data: {
                op: "address_default"
            },
            success: function(a) {
                var t = a.data;
                if ("" != t.data) {
                    var e = t.data.address;
                    "" != t.data.content && null != t.data.content && (e += t.data.content), d.setData({
                        name: t.data.name,
                        mobile: t.data.mobile,
                        address: e,
                        map: t.data.map
                    }), sign(d);
                }
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
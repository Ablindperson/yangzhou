var app = getApp(), common = require("../common/common.js");

Page({
    data: {},
    onLoad: function(o) {
        common.config(this), common.theme(this);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
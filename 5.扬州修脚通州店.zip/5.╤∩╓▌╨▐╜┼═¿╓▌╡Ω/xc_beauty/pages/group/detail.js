var app = getApp(), WxParse = require("../../../wxParse/wxParse.js"), common = require("../common/common.js");
//var app = getApp(), common = require("../common/common.js");

function timeup(t) {
    setInterval(function() {
        var a = t.data.list;
        -1 == a.status && (0 < parseInt(a.second) ? a.second = parseInt(a.second) - 1 : 0 < parseInt(a.min) ? (a.second = 59, 
        a.min = parseInt(a.min) - 1) : 0 < parseInt(a.hour) ? (a.second = 59, a.min = 59, 
        a.hour = parseInt(a.hour) - 1) : a.status = 2), t.setData({
            list: a
        });
    }, 1e3);
}

Page({
    data: {},
    menu_on: function() {
        var a = this;
        "theme3" == a.data.theme.name ? wx.navigateTo({
            url: "../../ui2/porder/porder?&id=" + a.data.list.pid + "&group=1&group_id=" + a.data.list.id
        }) : wx.navigateTo({
            url: "../porder/porder?&id=" + a.data.list.pid + "&group=1&group_id=" + a.data.list.id
        });
    },
    to_index: function() {
        console.log('to_index');
        (this.data.theme.name = "theme3") ? wx.redirectTo({
            url: "../../ui2/index/index"
        }) : wx.redirectTo({
            url: "../index/index"
        });
    },
    to_order: function() {
        var e = this.data
        console.log('to_order');
        //console.log('out_trade_no'+e.list.out_trade_no);
        console.log('gid'+e.grpid+' tid:'+ e.list.out_trade_no);
        wx.navigateTo({
            url: "../order/detail?&out_trade_no=" + e.list.out_trade_no+"&gid="+e.grpid,
        });
    },
    onLoad: function(a) {
        var e = this;
        var grpid = a.id
        common.config(e), common.theme(e), app.util.request({
            url: "entry/wxapp/order",
            data: {
                op: "group_detail",
                id: a.id
            },
            success: function(a) {
                var t = a.data;
                "" != t.data && (-1 == t.data.status && (t.data.hour = parseInt(t.data.fail / 3600), 
                t.data.min = parseInt((t.data.fail - 3600 * t.data.hour) / 60), t.data.second = t.data.fail % 60), 
                e.setData({
                    list: t.data,
                    grpid:grpid,
                }), timeup(e));
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {

        var a = "/xc_beauty/ui2/service/detail?&id=" + this.data.list.id,
            t = "/xc_beauty/pages/base/base?&share=" + (a = escape(a)),
            e = 1;
        return "" != app.share && null != app.share && "" != app.share.content && null != app.share.content && (e = app.share.content.status),
        1 == e && (t = t + "&scene=" + app.userinfo.openid), {
            //title: this.data.config.title + "-" + this.data.list.service.name,
            title:'一起拼单更划算',
            path: t,
            //imageUrl: this.data.list.service.simg,
            //desc: '一起拼单更划算',
            success: function(a) {
                //console.log(a);
            },
            fail: function(a) {
                console.log(a);
            }
        };


        //var a = this;
        //var t = '';
        //if ("theme3" == a.data.theme.name) t = "/xc_beauty/ui2/group/detail?&id=" + a.data.list.id;
        //t = "/xc_beauty/pages/group/detail?&id=" + a.data.list.id;
        ////t = "/xc_beauty/pages/base/base?&share=" + (a = escape(a));
        //var e = a.data.config.title + "-首页";
        //"" != a.data.list.service.name && null != a.data.list.service.name && (e = a.data.list.service.name);
        //var n = "";
        //"" != a.data.list.service.simg && null != a.data.list.service.simg && (n = a.data.list.service.simg);
        //var o = 1;
        //return "" != app.share && null != app.share && "" != app.share.content && null != app.share.content && (o = app.share.content.status),
        //1 == o && (t = t + "&scene=" + app.userinfo.openid), console.log(t), {
        //    title: e,
        //    path: t,
        //    imageUrl: n,
        //    success: function(a) {
        //        console.log(a);
        //    },
        //    fail: function(a) {
        //        console.log(a);
        //    }
        //};

    }
});
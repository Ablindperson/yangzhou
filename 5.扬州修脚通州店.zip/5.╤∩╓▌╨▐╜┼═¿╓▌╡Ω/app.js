App({
  

    onLaunch: function(e) {
      console.log("____",this)
        var o = this;
        o.ffff = e;
        var n = unescape(e.query.scene);
        console.log(e),
        "" != n && null != n && "undefined" != n && (0 < n.indexOf("c_beauty/pages/order/buy") ? "/" == n.slice(0, 1) ? o.buy_share = n : o.buy_share = "/" + n : o.scene = n);
   
   ///////////////////////////////




   
   /////////////
      // var that = this

      // var user = wx.getStorageSync('user') || {};
      // var userInfo = wx.getStorageSync('userInfo') || {};

      // var acid = wx.getStorageSync('acidObj')
      // console.log("acid", acid.acid)
      // console.log("userInfo", userInfo)
      // //判断是否已经获取过微信用户信息了 
      // if (!userInfo.openid) {
      //   wx.login({
      //     success: function (res) {
      //       console.log("res.code:", res.code)
      //        var codeobj = {}
      //       codeobj.code = res.code
      //       wx.setStorageSync('codeobj', codeobj)
      //       if (res.code) {
      //         wx.getUserInfo({
      //           success: function (res) {
      //             // console.log(res)
      //             // console.log("用户信息:", res.userInfo)//用户信息
      //             var objz = {};
      //             objz.avatarUrl = res.userInfo.avatarUrl;
      //             objz.nickName = res.userInfo.nickName;
      //             objz.gender = res.userInfo.gender;
      //             console.log("用户信息objz:", objz);
      //             wx.setStorageSync('userInfo', objz);//存储userInfo
      //             // console.log(objz.avatarUrl)

      //           }
      //           , fail(err) {
      //             wx.redirectTo({ url: '../btn/btn' })
      //           }
      //         });
      //       } else {
      //         console.log('获取用户登录态失败！' + res.errMsg)
      //       }
      //     }
      //   });
      // }

      // // console.log('最后一步');//这里开始第三步用获取的code 和会员信息换取openid
      // var userInfo = wx.getStorageSync('userInfo') || {};//获取用户信息
      // // var web_code = wx.getStorageSync('web_code1') || {};//获取网站code
      // var head_img = userInfo.avatarUrl + ""
      // var nick = userInfo.nickName
      // // console.log(userInfo)
      // var code = wx.getStorageSync('codeobj')
      // // console.log(code.code)
      // var codeRes = code.code
      // console.log(codeRes)
      // var l = 'https://wpdev.ligentshop.com/api/xcx/get_openid';//组装url 向网站发送请求 返回openid  但是现在 返回数据报错是500服务器报错
      // wx.request({
      //   url: l,
      //   method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT  
      //   header: {
      //     "content-type": "application/x-www-form-urlencoded"
      //   }, // 设置请求的 header  
      //   data: {
      //     code: codeRes,
      //     head_img: head_img,
      //     sex: userInfo.gender,
      //     nick: nick
      //   },
      //   success: function (res) {
      //     console.log("res--:", res)
      //     var obj = {};
      //     obj.openid = res.data.openid;
      //     console.log(obj.openid)
      //     // console.log("res.data.openid:", res.data.openid)
      //     obj.expires_in = Date.now() + res.data.expires_in;
      //     // console.log("obj:", obj);
      //     //存储openid  
      //     wx.setStorageSync('obj', obj);
      //     console.log("obj:", obj);
      //     // console.log("-------------:",util)
      //   },
     
      // });
   
   ///////////////////////
 
   
    },
    
    onShow: function(e) {},
    onHide: function() {},
    onError: function(e) {},
    util: require("we7/resource/js/util.js"),
    tabBar: {
        color: "#123",
        selectedColor: "#1ba9ba",
        borderStyle: "#1ba9ba",
        backgroundColor: "#fff",
        list: [ {
            pagePath: "/we7_wxappdemo/pages/index/index",
            iconPath: "/we7/resource/icon/home.png",
            selectedIconPath: "/we7/resource/icon/homeselect.png",
            text: "首页"
        }, {
            pagePath: "/we7_wxappdemo/pages/footer/footer",
            iconPath: "/we7/resource/icon/user.png",
            selectedIconPath: "/we7/resource/icon/userselect.png",
            text: "底部"
        }, {
            pagePath: "/we7_wxappdemo/pages/todo/todo",
            iconPath: "/we7/resource/icon/todo.png",
            selectedIconPath: "/we7/resource/icon/todoselect.png",
            text: "ToDo"
        }, {
            pagePath: "/we7_wxappdemo/pages/pay/pay",
            iconPath: "/we7/resource/icon/pay.png",
            selectedIconPath: "/we7/resource/icon/payselect.png",
            text: "支付"
        } ]
    },
    globalData: {
        userInfo: null
    },
    siteInfo: require("siteinfo.js")
});